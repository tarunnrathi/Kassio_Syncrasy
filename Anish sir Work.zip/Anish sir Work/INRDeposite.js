import axios from 'axios';
import React, { useState, useEffect } from 'react'
import { Link, withRouter, useParams } from 'react-router-dom';
import Swal from 'sweetalert2';
import Layout from '../../CommonComponent/Layout';
import baseURL from '../../URL/URL';
import * as Yup from 'yup';
import { useFormik , useFormikContext} from "formik";
import { useSelector } from 'react-redux';
import ReactTooltip from "react-tooltip";
import info from '../../Images/info.svg';
import { userDetails } from '../../Redux/Actions/userDetailsAction';
import { login } from '../../Redux/Actions/loginAction';
import { socketTickerCount } from '../../Redux/Actions/socketTickerCountAction';
import { connect } from 'react-redux';
import NewLoader from '../../CommonComponent/NewLoader';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import moment from 'moment';


const INRDeposite = (props) => {
    debugger

    const { values, submitForm } = useFormikContext();

    const { systemLevelParameters } = useSelector(state => state.SystemLevelParameters);
    let data = (systemLevelParameters.filter(x => x.parameterkey === "UPI_PAYMENT_ENABLED"||
                                                 x.parameterkey === "IMPS_PAYMENT_ENABLED"||
                                                 x.parameterkey === "MOBIKWIK_PAYMENT_ENABLED"||
                                                 x.parameterkey === "PAYPAL_PAYMENT_ENABLED"
                                    )).filter(x=>x.value==="YES");

    const [tabActive, setTabActive] = useState({ 
        preTab: data[0].parameterkey==="UPI_PAYMENT_ENABLED"
                ?((systemLevelParameters?.filter(x => x.parameterkey === "UPI_PAYMENT_ENABLED")).filter(x => x.value === "YES")).length > 0
                  ?false
                  :true
                :false,

        postTab: data[0].parameterkey==="IMPS_PAYMENT_ENABLED"
                ?((systemLevelParameters?.filter(x => x.parameterkey === "IMPS_PAYMENT_ENABLED")).filter(x => x.value === "YES")).length > 0
                  ?true
                  :false
                :false,  

        nextTab: data[0].parameterkey==="MOBIKWIK_PAYMENT_ENABLED"
        ?((systemLevelParameters?.filter(x => x.parameterkey === "MOBIKWIK_PAYMENT_ENABLED")).filter(x => x.value === "YES")).length > 0
            ?true
            :false
        :false, 
        
        payPal: data[0].parameterkey==="PAYPAL_PAYMENT_ENABLED"
        ?((systemLevelParameters?.filter(x => x.parameterkey === "PAYPAL_PAYMENT_ENABLED")).filter(x => x.value === "YES")).length > 0
            ?false
            :true
        :false, 
    });   

    const [apiData, setApiData] = useState({ upiAccounts: [], bankAccounts: [], virtualAccount: {}, specificCurrencyData: {} });
    const [loading, setLoading] = useState(false);
    const [manualTransactionlTabActive, setManualTransactionlTabActive] = useState(false);
    const initialValues = { amount: "" };
    const [transactionHistory, setTransactionHistory] = useState([]);
    const [loader, setLoader] = useState(true);
    const upiInputValues = { id: "", amount: "" };
    const [copySuccessTxtId, setCopySuccessTxtId] = useState('');
    const [copyIndex, setCopyIndex] = useState('');

    const { id } = useParams();
    
    
    let minAmount = systemLevelParameters?.filter(x => x.parameterkey === "INR_MANUAL_BANK_TRANSFER_MIN_DEPOSIT")[0]?.value;
    let maxAmount = systemLevelParameters?.filter(x => x.parameterkey === "INR_MANUAL_BANK_TRANSFER_MAX_WITHDRAWL")[0]?.value;

    useEffect(() => {
        debugger
        document.title = "INR Deposit - Kassio";
        let inputObj = {
            "filter": { "currencyId": `${id}` },
            "limit": "100",
            "offset": "0"
        }
        const { timeoutId } = Promise.all([
            axios.get(`${baseURL}/v1/bank/upi/details`),
            axios.get(`${baseURL}/v1/bank/account/get`),
            axios.get(`${baseURL}/v1/public/currency/specificCurrency?currencyId=${id}`),
            axios.get(`${baseURL}/v1/wallet/specificWallet?currencyId=${id}`),
        ]).then(reponses => {
            debugger
            if (reponses[0]?.data?.httpStatus === 200) {
                if ((reponses[0]?.data?.result?.filter(x => x.isVerified === true)).length > 0) {
                    setApiData({
                        ...apiData,
                        upiAccounts: (reponses[0]?.data?.result?.filter(x => x.isVerified === true)).length > 0
                            ? reponses[0]?.data?.result?.filter(x => x.isVerified === true)
                            : []
                    });
                }
                // else {
                //     Swal.fire({
                //         icon: "info",
                //         text: "Please add your UPI Id first",
                //         html: '<h4>Add UPI Account</h4>' +
                //             '<br/>' +
                //             '<p>Please approve the authorization request of the above amount on your selected UPI account to complete the deposit.</p>',
                //         reverseButtons: true,
                //         confirmButtonText: 'OK',
                //         // allowOutsideClick:false
                //     }).then(response => {
                //         //debugger
                //         if (response?.value) {
                //             props.history.push({
                //                 pathname: '/bankingPayment',
                //             });
                //         }
                //     });
                // }
            }
            if (reponses[1]?.data?.httpStatus === 200) {
                if ((reponses[1]?.data?.result?.bankAccounts?.filter(x => x.status === "VERIFIED")).length > 0) {
                    setApiData({
                        ...apiData,
                        upiAccounts: (reponses[0]?.data?.result?.filter(x => x.isVerified === true)).length > 0
                            ? reponses[0]?.data?.result?.filter(x => x.isVerified === true)
                            : [],
                        bankAccounts: (reponses[1]?.data?.result?.bankAccounts.filter(x => x.status === "VERIFIED")).length > 0
                            ? reponses[1]?.data?.result?.bankAccounts
                            : [],
                        virtualAccount: reponses[1]?.data?.result?.virtualAccount !== null || reponses[1]?.data?.result?.virtualAccount !== undefined
                            ? reponses[1]?.data?.result?.virtualAccount : {},
                        specificCurrencyData: reponses[2]?.data?.result
                    });
                }

                let inputObj = {
                    "filter": { "currencyId": `${id}` },
                    "limit": "10000",
                    "offset": "0"
                }
                return axios.post(`${baseURL}/v1/transactions/getTransactions`, inputObj)
            }
        }).then(response_transactions => {
            if (response_transactions?.data?.httpStatus === 200) {
                setTransactionHistory(response_transactions?.data?.result?.transactions);
                setLoader(false);
            }
        }).catch(error => {
            setLoader(false);
            if (error?.response?.data?.message) {
                if (error?.response?.data?.customErrorNumber === 100107) {
                    Swal.fire({
                        icon: "error",
                        text: "Login status expired"
                    }).then(() => {
                        props.login(false);
                        props.userDetails(null);
                        props.socketTickerCount([]);
                        localStorage.clear();
                        props.history.push("/");
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        text: error?.response?.data?.message
                    });
                }
            }
            // Swal.fire({
            //     icon:"error",
            //     text: "Something went wrong!!",               
            // });
        });
        return null;
    }, []);


    const validateInputField = Yup.object({
        amount: Yup.number()
            .required("Amount is Required!")
            .required("Amount is Required!")
            .min(systemLevelParameters?.filter(x => x.parameterkey === "INR_UPI_MIN_DEPOSIT")[0]?.value, `Minimum Deposit Amount is  ${systemLevelParameters?.filter(x => x.parameterkey === "INR_UPI_MIN_DEPOSIT")[0]?.value}`)
            .max(systemLevelParameters?.filter(x => x.parameterkey === "INR_UPI_MAX_DEPOSIT")[0]?.value, `Maximum Deposit Amount is ${systemLevelParameters?.filter(x => x.parameterkey === "INR_UPI_MAX_DEPOSIT")[0]?.value}`),
    });

    const paymentTAB = (value) => {
        debugger
        setManualTransactionlTabActive(false)
        if (value === "preTab") {
            if (apiData.upiAccounts.length > 0) {
                setTabActive({ preTab: true, postTab: false, nextTab: false, payPal: false });
            } else {
                setTabActive({ preTab: true, postTab: false, nextTab: false, payPal: false });
                // Swal.fire({
                //     icon: "info",
                //     text: "Please add your UPI Id first",
                //     html: '<h4>Add UPI Account</h4>' +
                //         '<br/>' +
                //         '<p>Please approve the authorization request of the above amount on your selected UPI account to complete the deposit.</p>',
                //     reverseButtons: true,
                //     confirmButtonText: 'OK',
                //     // allowOutsideClick:false
                // }).then(response => {
                //     debugger
                //     if (response?.value) {
                //         debugger
                //         props.history.push({
                //             pathname: "/bankingPayment",
                //             appAuthParams: {
                //                 key: "",
                //                 image_data: '',
                //                 url: ''
                //             }
                //         });
                //     }
                // });
            }
        }
        if (value === "postTab") {

            let a = systemLevelParameters;

            if (systemLevelParameters?.filter(x => x.parameterkey === "MANUAL_BANK_TRANSFER_ENABLED")[0]?.value === "YES") {
                setTabActive({ preTab: false, postTab: true, nextTab: false, payPal: false });
            } else {
                if (apiData.bankAccounts.length > 0) {
                    setTabActive({ preTab: false, postTab: true, nextTab: false, payPal: false });
                } else {
                    Swal.fire({
                        icon: "info",
                        text: "Please add your Bank Account first",
                        reverseButtons: true,
                        confirmButtonText: 'OK',
                    }).then(response => {
                        debugger
                        if (response?.value) {
                            props.history.push("/bankingPayment")
                        }
                    });
                }
            }


        }
        if (value === "nextTab") {
            setTabActive({ preTab: false, postTab: false, nextTab: true, payPal: false });
        }
        if (value === "payPal") {
            setTabActive({ preTab: false, postTab: false, nextTab: false, payPal: true });
        }
    };

    // payPal Deposite
    const formik = useFormik({
        initialValues: initialValues,
        validationSchema: validateInputField,
        onSubmit: (values) => {
            debugger
            setLoading(true);
            let inputObj = {
                "amount": values.amount
            };
            let URL = null;
            if (tabActive.nextTab) {
                URL = `${baseURL}/v1/transactions/mobikwikDepositInit`;
            }
            if (tabActive.payPal) {
                URL = `${baseURL}/v1/transactions/paypalDepositInit`;
            }

            axios.post(URL, inputObj).then((response) => {
                debugger
                if (response.data.httpStatus === 200) {
                    setLoading(false);
                    if (tabActive.nextTab) {
                        window.open(response?.data?.result?.mobikwikUrl, "_blank");
                    }
                    if (tabActive.payPal) {
                        window.open(response?.data?.result?.href, "_blank");
                    }
                }
            }).catch((error) => {
                if (error?.response?.data?.message) {
                    if (error?.response?.data?.customErrorNumber === 100107) {
                        Swal.fire({
                            icon: "error",
                            text: "Login status expired"
                        }).then(() => {
                            props.login(false);
                            props.userDetails(null);
                            props.socketTickerCount([]);
                            localStorage.clear();
                            props.history.push("/");
                        });
                    } else {
                        Swal.fire({
                            icon: "error",
                            text: error?.response?.data?.message
                        });
                    }
                }
                // Swal.fire({
                //     icon:"error",
                //     text:error?.response?.data?.message
                // })
                setLoading(false);
            });
        }
    });

    //   UPI validation     
    const upiValidateHandler = Yup.object({
        amount: Yup.number()
            .required("Amount is Required!")
            .min(systemLevelParameters?.filter(x => x.parameterkey === "INR_UPI_MIN_DEPOSIT")[0]?.value, `Minimum Deposit Amount is  ${systemLevelParameters?.filter(x => x.parameterkey === "INR_UPI_MIN_DEPOSIT")[0]?.value}`)
            .max(systemLevelParameters?.filter(x => x.parameterkey === "INR_UPI_MAX_DEPOSIT")[0]?.value, `Maximum Deposit Amount is ${systemLevelParameters?.filter(x => x.parameterkey === "INR_UPI_MAX_DEPOSIT")[0]?.value}`),
        id: Yup.string()
            .required('Select Your UPI Account!')
    });
    // UPI form submit
    const upiFormik = useFormik({
        initialValues: upiInputValues,
        validationSchema: upiValidateHandler,
        onSubmit: (values, { resetForm }) => {
            const inputObj = {
                "id": values.id.toString(),
                "amount": values.amount
            };
            let URL = `${baseURL}/v1/transactions/upi/init`;
            setLoading(true);
            axios.post(URL, inputObj)
                .then((response) => {
                    debugger
                    if (response?.data?.httpStatus === 200) {
                        debugger
                        Swal.fire({
                            icon: "success",
                            text: response.data && response.data.message
                        });
                        setLoading(false)
                        props.history.push("/wallet");
                    }
                    return true;
                }).catch((error) => {
                    if (error?.response?.data?.message) {
                        if (error?.response?.data?.customErrorNumber === 100107) {
                            Swal.fire({
                                icon: "error",
                                text: "Login status expired"
                            }).then(() => {
                                props.login(false);
                                props.userDetails(null);
                                props.socketTickerCount([]);
                                localStorage.clear();
                                props.history.push("/");
                            });
                        } else {
                            Swal.fire({
                                icon: "error",
                                text: error?.response?.data?.message
                            });
                        }
                    }
                    setLoading(false)
                    return false;
                });
            //   resetForm({id:"", amount:""})
        }

    });

    //manual bank transfer initial values
    const manualTransactionInitialValues = {
        "amount": "",
        "extTransactionId": "",
        "dateTime": ""
    };


    //manual bank transfer form validation 
    const manualTransactionValidation = Yup.object({
        amount: Yup.number()
            .required("Amount is Required!")
            .min(minAmount, `Minimum Amount Required ${minAmount}`)
            .max(maxAmount, `Maximum Amount Required ${maxAmount}`),
        extTransactionId: Yup.string().required("Reference ID is Required!")
    })

    //manual bank transfer form submit
    const manualTransactionForm = useFormik({
        initialValues: manualTransactionInitialValues,
        validationSchema: manualTransactionValidation,
        onSubmit: (values, { resetForm }) => {
            const inputObj = {
                "amount": values.amount.toString(),
                "extTransactionId": values.extTransactionId.toString(),
                "dateTime": ""
            };
            let URL = `${baseURL}/v1/transactions/manualDeposit`;
            setLoading(true);
            axios.post(URL, inputObj)
                .then((response) => {
                    setLoading(false);
                    debugger
                    if (response?.data?.httpStatus === 200) {
                        Swal.fire({
                            icon: "success",
                            title: "Deposit Request Saved",
                            text: "Your deposite request has been successfully saved"
                        }).then((response) => {
                            if (response?.value) {
                                resetForm({
                                    "amount": "",
                                    "extTransactionId": "",
                                    "dateTime": ""
                                })
                                props.history.push("/wallet")
                            }
                        })
                    }
                }).catch((error) => {
                    debugger
                    setLoading(false);

                    if (error?.response?.data?.message) {
                        if (error?.response?.data?.customErrorNumber === 100107) {
                            Swal.fire({
                                icon: "error",
                                text: "Login status expired"
                            }).then(() => {
                                props.login(false);
                                props.userDetails(null);
                                props.socketTickerCount([]);
                                localStorage.clear();
                                props.history.push("/");
                            });
                        } else {
                            Swal.fire({
                                icon: "error",
                                title: error?.response?.data?.message
                            }).then((response) => {
                                if (response?.value) {
                                    resetForm({
                                        "amount": "",
                                        "extTransactionId": "",
                                        "dateTime": ""
                                    })
                                    props.history.push("/wallet");
                                }
                            })
                        }
                    }
                })
        }
    });

    const copyFromHistory = (e, index) => {
        debugger
        setCopySuccessTxtId('Copied!')
        setCopyIndex(index);
        setTimeout(() => {
            setCopySuccessTxtId('');
        }, 1000);
    }

    return (
        <>
            <Layout />
            <div className="mainContent">
                <div className="mainInner">
                    <div className="pageTitle">
                        <div>
                            <h4>INR Deposit</h4>
                            <small><Link to="/wallet">&#x2190; Back to Wallet</Link></small>
                        </div>
                    </div>
                    <div className="tabsForm inrDepositPage">
                        <div className="tabsItems">
                            <ul>
                                {((systemLevelParameters?.filter(x => x.parameterkey === "UPI_PAYMENT_ENABLED")).filter(x => x.value === "YES")).length > 0
                                    ? <li><Link to="#" onClick={() => paymentTAB("preTab")} className={tabActive.preTab === true ? "tab-a active-a" : "tab-a"} data-id="tab1">UPI Transfer</Link></li>
                                    : null
                                }

                                {((systemLevelParameters?.filter(x => x.parameterkey === "IMPS_PAYMENT_ENABLED" || x.parameterkey === "NEFT_PAYMENT_ENABLED")).filter(x => x.value === "YES")).length > 0
                                    ? <li><Link to="#" onClick={() => paymentTAB("postTab")} className={tabActive.postTab === true ? "tab-b active-a" : "tab-b"} data-id="tab2">IMPS/NEFT Transfer</Link></li>
                                    : null
                                }

                                {((systemLevelParameters.filter(x => x.parameterkey === "MOBIKWIK_PAYMENT_ENABLED")).filter(x => x.value === "YES")).length > 0
                                    ? <li><Link to="#" onClick={() => paymentTAB("nextTab")} className={tabActive.nextTab === true ? "tab-c active-a" : "tab-c"} data-id="tab3">Mobikiwik</Link></li>
                                    : null
                                }

                                {((systemLevelParameters.filter(x => x.parameterkey === "PAYPAL_PAYMENT_ENABLED")).filter(x => x.value === "YES")).length > 0
                                    ? <li><Link to="#" onClick={() => paymentTAB("payPal")} className={tabActive.payPal === true ? "tab-d active-a" : "tab-d"} data-id="tab4">PayPal</Link></li>
                                    : null
                                }
                            </ul>
                        </div>
                        <div className="tabsContent">
                            {
                                tabActive.preTab && (
                                    <div className="tab tab-active" data-id="tab1">
                                        <div className="formArea">
                                            <form onSubmit={upiFormik.handleSubmit} autoComplete="off">
                                                <ul>
                                                    <li>
                                                        <div>
                                                            <label>Amount</label>
                                                            <input
                                                                type="text"
                                                                name="amount"
                                                                id="amount"
                                                                placeholder="Enter Amount"
                                                                onChange={upiFormik.handleChange}
                                                                onBlur={upiFormik.handleBlur}
                                                                value={upiFormik.values.amount}
                                                                maxLength={30}
                                                                onKeyPress={(event) => {
                                                                    let regex = new RegExp(/^\S/);
                                                                    let key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                                                                    if (!regex.test(key)) {
                                                                        event.preventDefault();
                                                                        return false;
                                                                    }
                                                                }}
                                                            />
                                                        </div>
                                                        {upiFormik.touched.amount && upiFormik.errors.amount
                                                            ? (
                                                                <div className="error">{upiFormik.errors.amount}</div>
                                                            )
                                                            : null
                                                        }
                                                    </li>
                                                    <li>
                                                        <label>Select UPI Account</label>
                                                        <div className="select">
                                                            <select
                                                                name="id"
                                                                id="id"
                                                                style={{ cursor: 'pointer' }}
                                                                value={upiFormik.values.id}
                                                                onChange={upiFormik.handleChange}
                                                                onBlur={upiFormik.handleBlur}>
                                                                <option value="" >--Select--</option>
                                                                {
                                                                    apiData.upiAccounts.length > 0 ? apiData.upiAccounts.map((item, index) => {
                                                                        return (
                                                                            <option key={index} value={item.id} >{item.vpa}</option>
                                                                        )
                                                                    })
                                                                        : null
                                                                }
                                                            </select>
                                                            {upiFormik.touched.id && upiFormik.errors.id
                                                                ? (
                                                                    <div className="error">{upiFormik.errors.id}</div>
                                                                )
                                                                : null
                                                            }
                                                        </div>
                                                        <br></br>
                                                        <div className="noteInst">
                                                            <p><strong>Note:</strong> You will recieve a request of above amount on the selected UPI account. Kindly approve the same to complete the deposit.</p>
                                                        </div>
                                                    </li>
                                                    <br />
                                                    <li className="btns">
                                                        <button type="submit">
                                                            {loading && (
                                                                <i className="fa fa-refresh fa-spin"
                                                                    style={{ fontSize: '20px', marginRight: "5px", marginTop: "5px" }}></i>
                                                            )}
                                                            {loading && <span>Sending</span>}
                                                            {!loading && <span>Send Request</span>}
                                                        </button>
                                                    </li>
                                                </ul>
                                            </form>
                                        </div>
                                    </div>
                                )
                            }
                            {
                                tabActive.postTab && (
                                    <div className="tab tab-active" data-id="tab2">
                                        <div className="formArea">
                                            {!manualTransactionlTabActive ?
                                                <div className="noteInst mb30">
                                                    <p data-tip data-for="icon">You can deposit INR via <strong>IMPS/NEFT</strong> from  your verified bank accounts only. Add below virtual account as payee and initiate the transfer.</p>
                                                </div>
                                                :
                                                <div className="noteInst mb30">
                                                    <p>Please provide amount and reference number for the deposite transaction</p>
                                                </div>
                                            }
                                            <ul>
                                                {systemLevelParameters?.filter(x => x.parameterkey === "MANUAL_BANK_TRANSFER_ENABLED")[0]?.value === "YES"
                                                    ?
                                                    <>
                                                        {!manualTransactionlTabActive ?
                                                            <>{apiData?.bankAccounts.length > 0
                                                                ? <>
                                                                    <li className="">
                                                                        <label>Account Details</label>
                                                                        <div className="virtualAcc">
                                                                            <ul>
                                                                                <li>
                                                                                    <label>Name</label>
                                                                                    <span>{systemLevelParameters?.filter(x => x.parameterkey === "MANUAL_BANK_TRANSFER_ACCOUNT_NAME")[0]?.value}</span>
                                                                                </li>
                                                                                <li>
                                                                                    <label>Account number</label>
                                                                                    <span>{systemLevelParameters?.filter(x => x.parameterkey === "MANUAL_BANK_TRANSFER_ACCOUNT_NUMBER")[0]?.value}</span>
                                                                                </li>
                                                                                <li>
                                                                                    <label>IFSC code</label>
                                                                                    <span>{systemLevelParameters?.filter(x => x.parameterkey === "MANUAL_BANK_TRANSFER_ACCOUNT_IIFSC")[0]?.value}</span>
                                                                                </li>
                                                                                <li>
                                                                                    <label>Type</label>
                                                                                    <span>{systemLevelParameters?.filter(x => x.parameterkey === "MANUAL_BANK_TRANSFER_ACCOUNT_TYPE")[0]?.value}</span>
                                                                                </li>
                                                                            </ul>
                                                                        </div>

                                                                    </li>
                                                                    <li className="btns">
                                                                        <button onClick={() => setManualTransactionlTabActive(true)}>I HAVE SENT THE AMOUNT</button>
                                                                    </li>
                                                                </>
                                                                : null
                                                            }
                                                            </>
                                                            :
                                                            <>
                                                                <div className="formArea">
                                                                    <form onSubmit={manualTransactionForm.handleSubmit} autoComplete="off">
                                                                        <ul>
                                                                            <li>
                                                                                <div>
                                                                                    <label>Amount</label>
                                                                                    <input
                                                                                        type="text"
                                                                                        name="amount"
                                                                                        id="amount"
                                                                                        placeholder="Enter Amount"
                                                                                        onChange={manualTransactionForm.handleChange}
                                                                                        onBlur={manualTransactionForm.handleBlur}
                                                                                        value={manualTransactionForm.values.amount}
                                                                                        maxLength={30}
                                                                                        onKeyPress={(event) => {
                                                                                            let regex = new RegExp(/^\S/);
                                                                                            let key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                                                                                            if (!regex.test(key)) {
                                                                                                event.preventDefault();
                                                                                                return false;
                                                                                            }
                                                                                        }}
                                                                                    />
                                                                                </div>
                                                                                {manualTransactionForm.touched.amount && manualTransactionForm.errors.amount
                                                                                    ? (
                                                                                        <div className="error">{manualTransactionForm.errors.amount}</div>
                                                                                    )
                                                                                    : null
                                                                                }
                                                                            </li>
                                                                            <li>
                                                                                <div>
                                                                                    <label>Reference ID</label>
                                                                                    <input
                                                                                        type="text"
                                                                                        name="extTransactionId"
                                                                                        id="extTransactionId"
                                                                                        placeholder="Enter Reference ID"
                                                                                        onChange={manualTransactionForm.handleChange}
                                                                                        onBlur={manualTransactionForm.handleBlur}
                                                                                        value={manualTransactionForm.values.extTransactionId}
                                                                                        maxLength={30}
                                                                                        onKeyPress={(event) => {
                                                                                            let regex = new RegExp(/^\S/);
                                                                                            let key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                                                                                            if (!regex.test(key)) {
                                                                                                event.preventDefault();
                                                                                                return false;
                                                                                            }
                                                                                        }}
                                                                                    />
                                                                                </div>
                                                                                {manualTransactionForm.touched.extTransactionId && manualTransactionForm.errors.extTransactionId
                                                                                    ? (
                                                                                        <div className="error">{manualTransactionForm.errors.extTransactionId}</div>
                                                                                    )
                                                                                    : null
                                                                                }
                                                                            </li>

                                                                            <br />
                                                                            <li className="btns">
                                                                                <button type="submit">
                                                                                    {loading && (
                                                                                        <i className="fa fa-refresh fa-spin"
                                                                                            style={{ fontSize: '20px', marginRight: "5px", marginTop: "5px" }}></i>
                                                                                    )}
                                                                                    {loading && <span>Sending</span>}
                                                                                    {!loading && <span>Confirm</span>}
                                                                                </button>
                                                                            </li>
                                                                        </ul>
                                                                    </form>
                                                                </div>
                                                            </>}

                                                    </>
                                                    :
                                                    <>
                                                        <li className="">
                                                            <label>Virtual Account Detail</label>
                                                            {
                                                                Object.keys(apiData.virtualAccount).length > 0
                                                                    ? (
                                                                        <div className="virtualAcc">
                                                                            <ul>
                                                                                <li>
                                                                                    <label>Name</label>
                                                                                    <span>{apiData?.virtualAccount?.benficiaryName}</span>
                                                                                </li>
                                                                                <li>
                                                                                    <label>Account number</label>
                                                                                    <span>{apiData?.virtualAccount?.accountNumber}</span>
                                                                                </li>
                                                                                <li>
                                                                                    <label>IFSC code</label>
                                                                                    <span>{apiData?.virtualAccount?.IFSC}</span>
                                                                                </li>
                                                                                <li>
                                                                                    <label>Bank Name</label>
                                                                                    <span>{apiData?.virtualAccount?.bankName}</span>
                                                                                </li>
                                                                            </ul>
                                                                        </div>
                                                                    ) : <p>No Virtual Account Found</p>
                                                            }

                                                            <div className="noteInst">
                                                                <p><strong>Note:</strong> Deposits from unverified accounts will fail and will be refunded</p>
                                                            </div>
                                                        </li>
                                                    </>
                                                }

                                                <br />

                                                <li className="verifiedAcc">
                                                    {apiData?.bankAccounts[0]?.accountNumber !== undefined ?

                                                        <>
                                                            <Link data-tip data-for="iconn" to="#">Your Verified Bank Accounts<img src={info} alt="#" /></Link>
                                                            <ReactTooltip id="iconn" type="info">
                                                                <span>{apiData?.bankAccounts[0]?.accountNumber}</span>
                                                                {/* {console.log(apiData?.bankAccounts[0]?.accountNumber)} */}
                                                            </ReactTooltip>
                                                        </>
                                                        :
                                                        <Link data-tip data-for="iconn" to="/bankingPayment">Add Verified Bank Accounts</Link>
                                                    }

                                                </li>
                                                <hr />
                                                <li className="verifiedAcc">
                                                    <Link to="#">INR deposit FAQs</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                )
                            }
                            {
                                tabActive.nextTab && (
                                    <div className="tab tab-active" data-id="tab3">
                                        <div className="formArea">
                                            <form onSubmit={formik.handleSubmit} autoComplete="off">
                                                <ul>
                                                    <li>
                                                        <div>
                                                            <label>Amount</label>
                                                            <input
                                                                type="text"
                                                                id="amount"
                                                                name="amount"
                                                                value={formik.values.amount}
                                                                onChange={formik.handleChange}
                                                                onBlur={formik.handleBlur}
                                                                maxLength={30}
                                                                onKeyPress={(event) => {
                                                                    let regex = new RegExp(/^\S/);
                                                                    let key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                                                                    if (!regex.test(key)) {
                                                                        event.preventDefault();
                                                                        return false;
                                                                    }
                                                                }}
                                                            />
                                                        </div>
                                                        {formik.touched.amount && formik.errors.amount
                                                            ? (
                                                                <div className="error">{formik.errors.amount}</div>
                                                            )
                                                            : null
                                                        }
                                                    </li>
                                                    <br />
                                                    <li className="btns">
                                                        <button type="submit">
                                                            {loading && (
                                                                <i className="fa fa-refresh fa-spin"
                                                                    style={{ fontSize: '20px', marginRight: "5px", marginTop: "5px" }}></i>
                                                            )}
                                                            {loading && <span>Sending</span>}
                                                            {!loading && <span>Send Request</span>}
                                                        </button>
                                                    </li>
                                                </ul>
                                            </form>
                                        </div>
                                    </div>
                                )
                            }
                            {
                                tabActive.payPal && (
                                    <div className="tab tab-active" data-id="tab4">
                                        <div className="formArea">
                                            <form onSubmit={formik.handleSubmit} autoComplete="off">
                                                <ul>
                                                    <li>
                                                        <div>
                                                            <label>Amount</label>
                                                            <input
                                                                type="text"
                                                                id="amount"
                                                                name="amount"
                                                                value={formik.values.amount}
                                                                onChange={formik.handleChange}
                                                                onBlur={formik.handleBlur}
                                                                maxLength={30}
                                                                onKeyPress={(event) => {
                                                                    let regex = new RegExp(/^\S/);
                                                                    let key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                                                                    if (!regex.test(key)) {
                                                                        event.preventDefault();
                                                                        return false;
                                                                    }
                                                                }}
                                                            />
                                                        </div>
                                                        {formik.touched.amount && formik.errors.amount
                                                            ? (
                                                                <div className="error">{formik.errors.amount}</div>
                                                            )
                                                            : null
                                                        }
                                                    </li>
                                                    <br />
                                                    <li className="btns">
                                                        <button type="submit">
                                                            {loading && (
                                                                <i className="fa fa-refresh fa-spin"
                                                                    style={{ fontSize: '20px', marginRight: "5px", marginTop: "5px" }}></i>
                                                            )}
                                                            {loading && <span>Sending</span>}
                                                            {!loading && <span>Send Request</span>}
                                                        </button>
                                                    </li>
                                                </ul>
                                            </form>
                                        </div>
                                    </div>
                                )
                            }
                        </div>
                    </div>
                    <div className='row listTable'>
                        <div className='dashTransaction tradeTable '>
                            <div className='cardHead cardPadd20'>
                                <h4>Transactions</h4>
                            </div>
                            <div className='table-responsive'>
                                <table className='table'>
                                    <thead>
                                        <tr>
                                            <th className="textLeft">Date</th>
                                            <th className="textLeft">Transaction Id</th>
                                            <th className="textLeft">Total Amount</th>
                                            <th className="textLeft">Fee</th>
                                            <th className="textLeft">Settlement Amount</th>
                                            <th className="textLeft">Type</th>
                                            <th className="textLeft">Status</th>
                                        </tr>
                                    </thead>
                                   
                                        {<tbody>
                                            {transactionHistory.length > 0 
                                            ? transactionHistory?.map((item, index) => {
                                                //debugger
                                                return (
                                                    <tr key={index}>
                                                        <td className="textLeft">
                                                            {/* { moment(item.updatedAt).format((systemLevelParameters.filter(x=>x.parameterkey==="DEFAULT_DATETIME_FORMAT"))[0].value)} */}
                                                            {/* { moment(item.updatedAt).format("DD/MM/yyyy HH:mm:ss")} */}
                                                            {(new Date(item.updatedAt)).toLocaleString()}
                                                        </td>
                                                        <td className="textLeft transIDAdd">  
                                                            <span className='tranID'>
                                                                {item.status === "SUCCESS" ? item.txId : item.id}                                                                   
                                                            </span>                                                               
                                                            <span className='tranCPY'>
                                                                <CopyToClipboard text={item.txId} onCopy={(e) => copyFromHistory(e, index)}>
                                                                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M18.3333 8.25H10.0833C9.07081 8.25 8.25 9.07081 8.25 10.0833V18.3333C8.25 19.3459 9.07081 20.1667 10.0833 20.1667H18.3333C19.3459 20.1667 20.1667 19.3459 20.1667 18.3333V10.0833C20.1667 9.07081 19.3459 8.25 18.3333 8.25Z" stroke="#7b7b7b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                                        <path d="M4.58301 13.7487H3.66634C3.18011 13.7487 2.7138 13.5555 2.36998 13.2117C2.02616 12.8679 1.83301 12.4016 1.83301 11.9154V3.66536C1.83301 3.17913 2.02616 2.71282 2.36998 2.369C2.7138 2.02519 3.18011 1.83203 3.66634 1.83203H11.9163C12.4026 1.83203 12.8689 2.02519 13.2127 2.369C13.5565 2.71282 13.7497 3.17913 13.7497 3.66536V4.58203" stroke="#7b7b7b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                                    </svg>
                                                                </CopyToClipboard>
                                                                {copySuccessTxtId && copyIndex === index && copySuccessTxtId}
                                                            </span>                                                                                                                             
                                                        </td>
                                                        <td className="textLeft">
                                                            {parseFloat(item.totalAmount).toString()}
                                                        </td>
                                                        <td className="textLeft">
                                                            {parseFloat(item.fee).toString() === "0" ? "0.00" : parseFloat(item.fee).toString()}
                                                        </td>
                                                        <td className="textLeft">
                                                            {parseFloat(item.settlementAmount).toString()}
                                                        </td>
                                                        <td className="textLeft">
                                                            {item.type}
                                                        </td>
                                                        <td className="textLeft">
                                                            {item.status}
                                                        </td>
                                                    </tr>
                                                )
                                            })
                                            :<tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td><h1>No Data Found!</h1></td>
                                            </tr>
                                            }
                                        </tbody>
                                    }
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default withRouter(connect(state => ({
    user: state.userDetails,
    isLogin: state.login,
    socketData: state.socketTicker,
}), { userDetails, login, socketTickerCount }
)(INRDeposite));