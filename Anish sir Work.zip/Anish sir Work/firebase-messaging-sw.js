// Scripts for firebase and firebase messaging
importScripts('https://www.gstatic.com/firebasejs/8.8.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.8.0/firebase-messaging.js');

// Initialize the Firebase app in the service worker by passing the generated config

const firebaseConfig = {
    apiKey: "AIzaSyDIMru2XcMJlUD7vhw9JrN1es7Sr9YWAx0",
    authDomain: "kassio-web.firebaseapp.com",
    projectId: "kassio-web",
    storageBucket: "kassio-web.appspot.com",
    messagingSenderId: "287315707682",
    appId: "1:287315707682:web:ffe628786d7b73a43a877b",
    measurementId: "G-K8JVFJ6436"
  };

firebase.initializeApp(firebaseConfig);

// Retrieve firebase messaging
const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  console.log('Received background message ', payload);

  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
  };

  self.registration.showNotification(notificationTitle,
    notificationOptions);
});