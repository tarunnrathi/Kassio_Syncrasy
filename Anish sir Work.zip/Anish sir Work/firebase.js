import firebase from 'firebase/app';
import 'firebase/messaging';

const firebaseConfig = {
    apiKey: "AIzaSyDIMru2XcMJlUD7vhw9JrN1es7Sr9YWAx0",
    authDomain: "kassio-web.firebaseapp.com",
    projectId: "kassio-web",
    storageBucket: "kassio-web.appspot.com",
    messagingSenderId: "287315707682",
    appId: "1:287315707682:web:ffe628786d7b73a43a877b",
    measurementId: "G-K8JVFJ6436"
  };

firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

export const getToken = (setTokenFound) => {
  return messaging.getToken({ vapidKey: 'BPZB1ykc2XNWOpjt6U38KlOUi2R362G-kVBeZ0ctWBTJLixLx4sJYE-PpaYeQkeGS1dEQth-UddRQGeylgSV6is' }).then((currentToken) => {
    if (currentToken) {
      console.log('current token for client: ', currentToken);
      setTokenFound(true);
      localStorage.setItem("currentToken", currentToken)
      // Track the token -> client mapping, by sending to backend server
      // show on the UI that permission is secured
    } else {
      console.log('No registration token available. Request permission to generate one.');
      setTokenFound(false);
      // shows on the UI that permission is required 
    }
  }).catch((err) => {
    console.log('An error occurred while retrieving token. ', err);
    // catch error while creating client token
  });
}

export const onMessageListener = () =>
  new Promise((resolve) => {

    messaging.onMessage((payload) => {
      resolve(payload);
    });
  });