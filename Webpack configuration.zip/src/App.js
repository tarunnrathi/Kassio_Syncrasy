import React, { Suspense } from "react";
import './Styles/style.css';
import { hot } from "react-hot-loader";
import { BrowserRouter as Router, Routes, Switch, Route } from "react-router-dom";
import { PersistGate } from "redux-persist/integration/react";
import { persistor } from './Redux/Store/store';
import { publicRoutes } from "./RoutesConfiguration/routes";
import PublicRoutes from "./RoutesConfiguration/PublicRoutes";

const App = () => {
  return (
    <PersistGate key={persistor} loading={null} persistor={persistor}>
      
      <Router>
        
          <Suspense
            fallback=
            {<p style={{ left: "35%", padding: 200, position: "relative" }}>
            </p>
            }
          >
            <Routes>
              {publicRoutes.map(({ path, Component }, index) => {
                return (
                  <React.Fragment key={path + index}>
                    <Route path={path} isAuthenticated={false} element={<Component />} />
                  </React.Fragment>
                )
              })}
            </Routes>
          </Suspense>
        
      </Router>
      
    </PersistGate>
  );
}
export default hot(module)(App);