const LocalStorageService = (() => {
    var _service;
    const _getService = () => {
        debugger
        if (!_service) {
            _service = this;
            return _service;
        }
        return _service;
    }

    const _setToken = (tokenObj) => {
      // 
      debugger   
        
            let encryptedVlaue = window.CryptoJS.AES.encrypt(tokenObj.access_token, process.env.REACT_APP_AUTH_SECRET_KEY);
            localStorage.setItem(`access_token`, encryptedVlaue);
           
        
    }

    const _setRefreshToken = (tokenObj) => {
       //   
       debugger
            let encryptedVlaue = window.CryptoJS.AES.encrypt(tokenObj.refresh_token, process.env.REACT_APP_AUTH_SECRET_KEY);
            localStorage.setItem(`refresh_token`, encryptedVlaue);
        
    }


    const _getAccessToken = () => {
       //   
       debugger
        let x = localStorage?.getItem(`access_token`);
        if(x){
           
                let decrypted = window.CryptoJS.AES.decrypt(x,process.env.REACT_APP_AUTH_SECRET_KEY);
                return  decrypted.toString(window.CryptoJS.enc.Utf8);               
           
        }else{
            return false;
        }
    }

    const _getRefreshToken = () => {
       // 
       debugger  
            let decrypted = window.CryptoJS.AES.decrypt(localStorage.getItem(`refresh_token`),process.env.REACT_APP_AUTH_SECRET_KEY);
            return  decrypted.toString(window.CryptoJS.enc.Utf8);               
    }

    const _clearToken = () => {
       // 
       debugger  
        localStorage.removeItem(`access_token`);
        localStorage.removeItem(`refresh_token`);
    }

    const _clearRefreshToken = () => {
        debugger
        localStorage.removeItem(`refresh_token`);
    }

    return {
        getService: _getService,
        setToken: _setToken,
        setRefreshToken: _setRefreshToken,
        getAccessToken: _getAccessToken,
        getRefreshToken: _getRefreshToken,
        clearToken: _clearToken,
        clearRefreshToken: _clearRefreshToken
    }
})();
export default LocalStorageService;