import React, { useEffect, useState } from "react";
import validateURL from "./ValidateURL";
import { useLocation,Link } from "react-router-dom";


const Header = (props) => {
    const { pathname } = useLocation();
    const [count, setCount] = useState(0);
    const [isResponsive, setIsResponsive] = useState(false);
    const handleScroll = () => {
        const scrolled = window.scrollY;
        setCount(scrolled);       
    };
    useEffect(() => {
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    const responsive = () => {
        setIsResponsive(!isResponsive);
    };

    return (
        <React.Fragment>            
            <header className={count >= 200 ? "header sticky" : "header"}>
                <div className="container">
                    <div className="brand">
                        <a href={validateURL("https://kassio.com")?"https://kassio.com":""} >
                            <img src={validateURL("https://asset.kassio.com/asset/kassio/Kassio-logo.svg") ? "https://asset.kassio.com/asset/kassio/Kassio-logo.svg" : ''} alt="Kassio" title="Kassio" />
                        </a>
                    </div>
                    <div
                        className={
                            isResponsive === false && props.menuClose === true
                                ? "mobileMenu floatRight active"
                                : "mobileMenu floatRight"
                        }
                        onClick={responsive}
                    >
                        <span className="stick1"></span>
                        <span className="stick2"></span>
                        <span className="stick3"></span>
                    </div>
                    <div className={isResponsive ? "mainMenu active" : "mainMenu"}>
                        <ul>
                            <li onClick={responsive}><a className={props.locaton === '/cards' ? "activeNav" : ""} href={validateURL("https://kassio.com/cards") ? "https://kassio.com/cards" : ''}>Card</a></li>
                            <li onClick={responsive}><a className={props.locaton === '/trade' ? "activeNav" : ""} href={validateURL("https://kassio.com/trade") ? "https://kassio.com/trade" : ''}>Trade</a></li>
                            <li onClick={responsive}><a className={props.locaton === '/borrow' ? "activeNav" : ""} href={validateURL("https://kassio.com/borrow") ? "https://kassio.com/borrow" : ''}>Borrow</a></li>
                            <li onClick={responsive}><a className={props.locaton === '/earn' ? "activeNav" : ""} href={validateURL("https://kassio.com/earn") ? "https://kassio.com/earn" : ''}>Earn</a></li>
                            <li onClick={responsive}><a className={props.locaton === '/wallet' ? "activeNav" : ""} href={validateURL("https://kassio.com/wallet") ? "https://kassio.com/wallet" : ''}>Wallet</a></li>
                            <li onClick={responsive}><a className={props.locaton === '/businesses' ? "activeNav" : ""} href={validateURL("https://kassio.com/businesses") ? "https://kassio.com/businesses" : ''}>Businesses</a></li>                           
                            <li onClick={responsive} className="sign_up joinWaitlist"><Link to={pathname==="/"?"/signup":"/"} className="btn">{pathname==="/"?"Sign Up":"Log In"}</Link></li>
                        </ul>
                    </div>
                </div>
            </header>
        </React.Fragment>
    )
}
export default Header;