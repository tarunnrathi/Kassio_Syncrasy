import React from 'react'
import networkError from '../Images/nointernet.png';


const NetworkConnectivity = () => {
  return (
    <section className='noInternet'>
        <div className='intContainer'>
            <img src={networkError} alt="#" />
            <h4>No Internet Connection!</h4>
            <p>Oops... That page is not available since you are not connected to the Internet.</p>
            {/* <ul>
                <li>Checking the network cables, modem, and router</li>
                <li>Reconnecting to Wi-Fi</li>
            </ul> */}
            {/* <button className='btn'>Retry</button> */}
        </div>
    </section>
  )
}
export default NetworkConnectivity;