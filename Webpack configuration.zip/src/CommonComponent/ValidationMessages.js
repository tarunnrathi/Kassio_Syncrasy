const ValidationMsg = {
    validateEmail:value=>{
        //debugger
        if(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(value)){
            return "";
        }else{
            return "Invalid Email."
        }
    },
    validateSignInPassword:value=>{
        var regex = {            
            'full': /^((?!.*[\s])(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#?&%$*]).{8,17})/
        };        
        if (regex.full.test(value)){
           return "";
        }else{
            return "Invalid Password";
        }
    },
    // sign up module
    validateFirstName:value=>{
        debugger  
        if(/^(?=^\w{1,5}$)[a-zA-Z0-9]$/.test(value)){
            return "";
        }else{
            return 'White space and special characters are not allowed'
        }       
        // if(/^(?=^\w{1,5}$)[a-z0-9]$/.test(value)){
        //     return "";
        // }else{
        //     if(/^(?=^\w{1,5}$)[a-z0-9]$/.test(value)){
        //         return 'Max 100 characters are allowed.'
        //     }else{
        //         return 'White space and special characters are not allowed'
        //     }            
        // }
    },
    validateLastName:value=>{  
        if(/^(?=^\w{1,5}$)[a-zA-Z0-9]$/.test(value)){
            return "";
        }else{
            return 'White space and special characters are not allowed'
        }
    },
    validateSignUpPassword:(value)=>{ 
        //debugger 
        var regex = {
            capital: /(?=.*[A-Z])/,
            small: /(?=.*[a-z])/,
            digit: /(?=.*[0-9])/,
            special: /(?=.*[!@#?&%$*])/,
            length: /(?=.{8,17})/,
            full: /^((?!.*[\s])(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#?&%$*]).{8,17})/,
          };
          if(!regex.length.test(value)) {
              return "Password length atleast 8 to 16 characters"
          }
          if(!regex.capital.test(value)) {    
              return  "Password should contain at least one upper case Letter"
          }
          if(!regex.small.test(value)) {
            return "Password should contain at least one lower case Letter"
         }
         if(!regex.digit.test(value)) {
            return "Password should contain at least one digit"
        }
       if(!regex.special.test(value)) {
            return "Password should contain at least one special character !@#?&%$*"
        }
        if(!regex.full.test(value)) {
            return 'Password should not contain whitespace'
        }
          return true;
    },
}
export default ValidationMsg;