import React, { useState,useEffect } from "react";
import Header from "../../CommonComponent/Headers";
import { Link, useNavigate } from "react-router-dom"; 
 import ValidationMsg from "../../CommonComponent/ValidationMessages";
import { useDispatch, useSelector } from "react-redux";
import { loginUser } from "../../Redux/Actions/User";
import { getSystemLevelParameters } from "../../Redux/Actions/systemParameters";
import Recaptcha from "react-google-recaptcha";
import axios from "axios";
import SweetAlert from 'sweetalert2'

const SignIn = (props) => {  
  debugger
  const [inputValues, setInputValues] = useState({ email: '', password: '' });
  const [error, setError] = useState({ errorEmail: '', errorPassword: '' });
  const [isRevealPwd, setIsRevealPwd] = useState(false);
 // const [loading, setLoading] = useState(false);
  const [ip, setIP] = useState('');
  const [captchValue, setCaptchValue] = useState('');

  const dispatch = useDispatch();
  const {loading} = useSelector((state)=> state.login);

  const navigate = useNavigate();




  useEffect(() => {
    // checkDevice();
    document.title = "Kassio";
        axios.get('https://ipapi.co/json/')
        .then(reponses => {
         // debugger
            setIP(reponses[0]?.data?.ip || "");
        }).catch(error => {
            //console.log(error);
        })
    return () => {
        setIP('');
    };
}, []);

  useEffect(() => {
    dispatch(getSystemLevelParameters())
  },[dispatch]);


  // Captcha ChangeHandler
  const handleGoogleCaptcha = (value) => {
    setCaptchValue(value);
  };

  // InputBox change handler
  const onChangeHandler = (e) => {
    const { name, value } = e.target;
    setInputValues({ ...inputValues, [name]: value });
    if(value === ""){
      setError({errorEmail:"", errorPassword:"" }); 
    }    
    if(name === "email"){
      setError({...error,
        errorEmail:ValidationMsg.validateEmail(value),
        errorPassword:""
      }); 
    }
    if(name === "password"){
      setError({...error,
        errorEmail:"",
        errorPassword:ValidationMsg.validateSignInPassword(value)
      }); 
    }
    
  }

  // Form Submit handler
  const submitHandler = (e) =>{
    debugger
    e.preventDefault();  
    let systemInfo = navigator.appVersion.split(' '); 
    if(ValidationMsg.validateEmail(inputValues.email) === "" && ValidationMsg.validateSignInPassword(inputValues.password)==="" && captchValue !== ""  ){
        setError({...error,errorEmail:"",errorPassword:""});  
      let inputObj = {
        "email": inputValues.email,
        "password": inputValues.password,
        "deviceName": systemInfo[2] + " " + systemInfo[3] + " " + systemInfo[8],
        "deviceId": ip,
        "googleCaptcha": captchValue
    } 
    dispatch(loginUser(inputObj,navigate));
    }else{      
      setError({...error,
        errorEmail:ValidationMsg.validateEmail(inputValues.email),
        errorPassword:ValidationMsg.validateSignInPassword(inputValues.password)
      });      
    }
  };

  return (
    <React.Fragment>
      <Header />
     
      <div className="popParent">
        <section className="prePopCent">
          <div className="">
            <div className="heading">
              <h5>Login Now</h5>
              <p>Please continue login</p>
            </div>
            <div className="formBody">
              <form autoComplete="off">
                <ul>
                  <li>
                    <label>Email</label>
                    <input type="email" name="email"
                      placeholder="Enter Email"
                      maxLength={200}
                      onChange={onChangeHandler}
                      tabIndex="-1"
                      onKeyPress={(event) => {
                        let regex = new RegExp(/^\S/);
                        let key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                        if (!regex.test(key)) {
                          event.preventDefault();
                          return false;
                        }
                      }}
                      autoComplete="off"
                      required
                    />
                    {error.errorEmail &&
                      <span className="error">{error.errorEmail}</span>
                    }
                  </li>

                  <li className="eyeHide">
                    <label>Password</label>
                    <input type={isRevealPwd ? "text" : "password"}
                      name="password" placeholder="Enter Password" onChange={onChangeHandler}
                      onPaste={(e) => {
                        e.preventDefault()
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault()
                        return false;
                      }}
                      onKeyPress={(event) => {
                        let regex = new RegExp(/^\S/);
                        let key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
                        if (!regex.test(key)) {
                          event.preventDefault();
                          return false;
                        }
                      }}
                      maxLength={16}
                      autoComplete="off"
                    />
                    <div className="eyeSetup">
                      <span className="pwd-container">
                        <img
                          title={isRevealPwd ? "Hide password" : "Show password"}
                          src={!isRevealPwd ? process.env.REACT_APP_IMAGE_BASE_URL + '/hide-password.svg' : process.env.REACT_APP_IMAGE_BASE_URL + '/show-password.svg'}
                          onClick={() => setIsRevealPwd(prevState => !prevState)}
                          alt="#"
                        />
                      </span>
                    </div>
                    {error.errorPassword  &&
                      <span className="error">{error.errorPassword}</span>
                    }
                  </li>
                  <li className="clear frgtWbtn">
                    <p className="forgotPass"><Link to="/forgotpassword">Forgot Password?</Link></p>
                    {/* <button className="btn btnWithLoader" onClick={submitHandler} disabled={!isCaptchaValidate?._store.validated}> */}
                    <p className="forgotPass"><a href="https://kassio.com/privacypolicy" target="_blank" rel="noreferrer">Privacy Policy</a></p>
                  </li>
                  <li>
                    <Recaptcha
                      sitekey={process.env.REACT_APP_GOOGLE_CAPCHA_PUBLIC_SITE_KEY}
                      onChange={handleGoogleCaptcha}
                    />
                    {!captchValue &&
                      <span className="error">Please Select Your Captcha</span>
                    }
                  </li>
                  <li className="mt30">
                    <button type="submit" className="btn btnWithLoader w100" onClick={submitHandler} disabled={loading}>
                      {loading && (
                        <img src={process.env.REACT_APP_IMAGE_BASE_URL + '/loader.svg'} alt="#" />
                      )}
                      {loading && <span>Loading</span>}
                      {!loading && <span>Login</span>}
                    </button>
                  </li>
                  <li className="clear goToSignUp mb-0 pt10">
                    <p>Don’t have an account? <Link to="#" onClick={() => props.history.push("/signup")}>Sign Up</Link></p>
                  </li>                 
                </ul>
              </form>
            </div>
          </div>

        </section>
      </div>
    </React.Fragment>
  )
}
export default SignIn;