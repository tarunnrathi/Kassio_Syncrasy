import React, { useState, useEffect } from "react";
// import baseURL from "../../URL/URL";
import axios from "axios";
import Swal from "sweetalert2"
// import LocalStorageService from "../../AuthServices/Storage/LocalStorageService";
import OtpInput from 'react-otp-input';
// import { ErrorHandlingPreLogin } from "../../CommonComponent/ErrorHandling";

const EmailOTPVerification = (props) => {

    const [inputValues, setInputValues] = useState({ otpDigit: '' });
    const [loading, setLoading] = useState(false);
    const [otpCounter, setOtpCounter] = useState(60);

    const onChangeHandler = (otp) => {
        setInputValues({ otpDigit: otp })
    }

    // EMAIL Varification
    const emailVarification = (e) => {
        e.preventDefault();
        if (inputValues.otpDigit !== null && inputValues.otpDigit !== "" && inputValues.otpDigit.length === 6) {
            let inputObj = {
                otp: inputValues.otpDigit,
                deviceName: "oppo",
                deviceId: "432"
            }
            setLoading(true);
            let URL = `${baseURL}/v1/auth/signUpEmailOTPVerify`;
            axios.post(URL, inputObj)
                .then(response => {
                      
                    if (response.data.httpStatus === 200) {
                        if (!LocalStorageService.getService()) {
                            let tokenObj = {
                                access_token: response.data.result.jwtToken,
                                // refresh_token:response.data.result.jwtToken,
                            };
                            LocalStorageService.setToken(tokenObj);
                        }
                        setLoading(false);
                        Swal.fire({
                            icon: "success",
                            title: "",
                            html: '<h4>Email Verified Successfully!</h4>' +
                                '<p>Your email OTP is successfully verified.</p>',
                            confirmButtonText: 'Close',
                        }).then(reponse => {
                              
                            if (reponse.value) {
                                props?.setDisplayPopup(false);
                            }
                        });
                    }
                })
                .catch(error => {
                    setInputValues({ otpDigit: '' })
                    // ErrorHandlingPreLogin(error);                    
                    setLoading(false);
                });
        } else {
            Swal.fire({
                icon: "error",
                text: "Invalid OTP!!",
            });
        }
    };


    useEffect(() => {
        let timer = setTimeout(() => {
            setOtpCounter(otpCounter - 1)
        }, 1000);
        return () => clearTimeout(timer);
    }, [otpCounter]);

    // OTP Resend Email
    const reSendEmailOTP = (e) => {
        e.preventDefault();
        let URL = `${baseURL}/v1/auth/signUpResendEmailOTP`;
        axios.post(URL)
            .then(response => {
                Swal.fire({
                    icon: "success",
                    text: response.data.message,
                });
                setInputValues({ ...inputValues, otpDigit: '' });
                setOtpCounter(60);
            }).catch(error => {
                setInputValues({ ...inputValues, otpDigit: '' });
                // ErrorHandlingPreLogin(error);                        
            });
    }

    return (
        <div>
            <section className="preLoginForms">
                <div className="allForms">
                    <div className="heading">
                        <img className="emailOTPImg" src={process.env.REACT_APP_IMAGE_BASE_URL + '/emailOTP.png'} alt="#" />
                        <h5>Email Verification</h5>
                        <p>Enter your verification code sent to<br /><strong>{props.Email}</strong></p>
                    </div>
                    <div className="formBody otpForm">
                        <form onSubmit={emailVarification} autoComplete='off'>
                            <div className="inputSec">
                                <OtpInput
                                    className="otpInput"
                                    value={inputValues.otpDigit}
                                    onChange={onChangeHandler}
                                    numInputs={6}
                                    separator={<span>-</span>}
                                    isInputNum={true}
                                    shouldAutoFocus={true}
                                />
                            </div>
                            <div className="goToSignUp mt30 mb30">
                                {
                                    otpCounter > 0 ? <span>Expires In 0:{otpCounter} sec</span> : <div className="goToSignUp mt30 mb30"><p>Didn’t Receive OTP? <a href="#/" onClick={reSendEmailOTP}>Resend OTP</a></p></div>
                                }
                            </div>
                            <div className="clear w100 mt30 mb30">
                                <div className="floatLeft levels">
                                    <span className="level1 active">1</span>
                                    <span className="level2 active">2</span>
                                    <span className="level3 active">3</span>
                                </div>
                                <div className="floatRight">
                                    <button className="btn btnWithLoader" type="submit" onClick={emailVarification}>
                                        {loading && (
                                            <img src={process.env.REACT_APP_IMAGE_BASE_URL + '/loader.svg'} />
                                        )}
                                        {loading && <span>Loading</span>}
                                        {!loading && <span>Confirm</span>}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </section>
        </div>
    )

}

export default EmailOTPVerification;