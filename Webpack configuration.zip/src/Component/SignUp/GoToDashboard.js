import React,{ useEffect }  from "react";
// import baseURL from '../../URL/URL';
// import axios from 'axios';
// import { userDetails } from '../../Redux/Actions/userDetailsAction';
// import { login } from '../../Redux/Actions/loginAction';
// import { socketTickerCount } from '../../Redux/Actions/socketTickerCountAction';
import { withRouter } from 'react-router';
import { connect } from "react-redux";
// import { ErrorHandlingPreLogin } from "../../CommonComponent/ErrorHandling";
import {useSelector, useDispatch} from "react-redux";


const GoToDashboard = (props) => { 
    const dispatch = useDispatch();

    // useEffect(() => {
    //     let URL= `${baseURL}/v1/user/details`;
    //     axios.get(URL)
    //     .then(response_userDetails=>{            
    //         if(response_userDetails.data.httpStatus===200){
    //             props.userDetails(response_userDetails.data.result);                     
    //         }
    //         return axios.get(`${baseURL}/v1/market/details`);  
    //     }).then(response_socketTickerData=>{            
    //         if(response_socketTickerData.data.httpStatus===200){
    //             props.socketTickerCount(response_socketTickerData.data.result);
    //             props.login(true);                    
    //             props.history.push("/dashboard");
    //         }
    //     }).catch(error=>{
    //         // ErrorHandlingPreLogin(error);                                   
    //     });        
    // }, [props]);
    // return (
    //    null
    // )
};


export default GoToDashboard;

// export default connect(state=>({
//     user:state.userDetails,
//     isLogin:state.login,
//     socketData:state.socketTicker
//    }),{userDetails,login,socketTickerCount}
// )(withRouter(GoToDashboard));