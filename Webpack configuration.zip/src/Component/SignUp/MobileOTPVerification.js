import React, { useState, useEffect } from "react";
// import baseURL from "../../URL/URL";
// import axios from "axios";
import Swal from "sweetalert2";
import OtpInput from 'react-otp-input';
// import { ErrorHandlingPreLogin } from "../../CommonComponent/ErrorHandling";

const MobileOTPVerification = (props) => {
    const [inputValues, setInputValues] = useState({ otpDigit: '' });
    const [loading, setLoading] = useState(false);
    const [otpCounter, setOtpCounter] = useState(60);

    useEffect(() => {
        let timer = setTimeout(() => {
            setOtpCounter(otpCounter - 1)
        }, 1000);
        return () => clearTimeout(timer);
    }, [otpCounter])


    const onChangeHandler = (otp) => {
        setInputValues({ otpDigit: otp })
    }


    // OTP Varification
    const otpVarification = (e) => {
        e.preventDefault();
        if (inputValues.otpDigit !== null && inputValues.otpDigit !== "" && inputValues.otpDigit.length === 6) {
            let inputObj = {
                otp: inputValues.otpDigit
            }
            setLoading(true);
            let URL = `${baseURL}/v1/auth/signUpPhoneOTPVerify`;
            axios.post(URL, inputObj)
                .then(response => {
                    if (response.data.httpStatus === 200) {
                        setInputValues({ ...inputValues, otpDigit: '' })
                        setLoading(false);
                        Swal.fire({
                            icon: "success",
                            title: "",
                            html: '<h4>Mobile Verified Successfully!</h4>' +
                                '<p>Your mobile OTP is successfully verified.</p>',
                            confirmButtonText: 'Next',
                        }).then(reponse => {
                              
                            if (reponse.value) {
                                props?.isEmailVerify(true);
                                // props?.setDisplayPopup(false); 
                            }
                        });
                    }
                })
                .catch(error => {
                      
                    //ErrorHandlingPreLogin(error);                    
                    setLoading(false);
                    setInputValues({ otpDigit: "" });
                });
        } else {
            Swal.fire({
                icon: "info",
                text: "Please provide OTP",
            });
        }
    }

    // OTP Resend
    const reSendOTP = (e) => {
        e.preventDefault();
        let URL = `${baseURL}/v1/auth/signUpResendPhoneOTP`;
        axios.post(URL)
            .then(response => {
                Swal.fire({
                    icon: "success",
                    text: response.data.message,
                });
                setInputValues({ ...inputValues, otpDigit: '' });
                setOtpCounter(60)
            }).catch(error => {
                //ErrorHandlingPreLogin(error);                
            });
    }

    return (
        <div>
            <section className="preLoginForms">
                <div className="allForms">
                    <div className="heading">
                        <img className="emailOTPImg" src={process.env.REACT_APP_IMAGE_BASE_URL + '/mobileOTP.png'} alt="#" />
                        <h5>Enter Mobile OTP</h5>
                        <p>Enter your verification code sent to<br />
                            <strong>{props.CountryCode + '-' + props.MobileNo}</strong></p>
                    </div>
                    <div className="formBody otpForm">
                        <form onSubmit={otpVarification} autoComplete='off'>
                            <div className="inputSec">
                                <OtpInput
                                    className="otpInput"
                                    value={inputValues.otpDigit}
                                    onChange={onChangeHandler}
                                    numInputs={6}
                                    separator={<span>-</span>}
                                    isInputNum={true}
                                    shouldAutoFocus={true}
                                />
                            </div>
                            <div className="goToSignUp mt30 mb30">
                                {
                                    otpCounter > 0 ? <span>Expires In 0:{otpCounter} sec</span> : <div className="goToSignUp  mt30 mb30"><p>Didn’t Receive OTP? <a href="#/" onClick={reSendOTP}>Resend OTP</a></p></div>
                                }
                            </div>
                            <div className="stepsBTN mt30">
                                <div className="levels">
                                    <span className="level1 active">1</span>
                                    <span className="level2 active">2</span>
                                    <span className="level3">3</span>
                                </div>

                                <div className="">
                                    <button className="btn btnWithLoader floatRight" type="submit" onClick={otpVarification}>
                                        {loading && (
                                            <img src={process.env.REACT_APP_IMAGE_BASE_URL + '/loader.svg'} />
                                        )}
                                        {loading && <span>Loading</span>}
                                        {!loading && <span>Confirm</span>}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    )
}

export default MobileOTPVerification;