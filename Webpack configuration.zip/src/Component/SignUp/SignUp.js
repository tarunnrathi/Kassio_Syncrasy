import React, { useEffect, useState } from "react";
import Header from "../../CommonComponent/Headers";
// import baseURL from "../../URL/URL";
import axios from "axios";
import LocalStorageService from "../../AuthServices/Storage/LocalStorageService";
import MobileOTPVerification from "./MobileOTPVerification";
import EmailOTPVerification from "./EmailOTPVerification";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import GoToDashboard from "./GoToDashboard";
import { useTranslation } from "react-i18next";
import { Link, useLocation,useNavigate } from "react-router-dom";
import Recaptcha from "react-google-recaptcha";
import { useSelector, useDispatch } from "react-redux";
// import underMaintenanceIcon from '../../Images/under maintenance Icon.svg';
// import { ErrorHandlingPreLogin } from "../../CommonComponent/ErrorHandling";
import { Offline, Online } from "react-detect-offline";
import NetworkConnectivity from "../../CommonComponent/NetworkConnectivity";
import { signUpUserInit } from "../../Redux/Actions/User";
import ValidationMsg from "../../CommonComponent/ValidationMessages";

const SignUp = (props) => {
  // debugger
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { search } = useLocation();
  let param = new URLSearchParams(search);
  //let f = param.get("refcode");
  //let h = param.get("name");

  // Variables Initialization
  const { t } = useTranslation();
  const [inputValues, setInputValues] = useState({
    fName: "",
    lName: "",
    email: "",
    countryCode: "",
    phone: "",
    password: "",
    isTNCAccepted: false,
    referredCode: param.get("refcode") || "",
  });
  const [submitted, setSubmitted] = useState(false);
//   const [passwordValidation, setPasswordValidation] = useState({
//     passwordValidate: false,
//     passwordTexterror: "",
//   });
  const [isRevealPwd, setIsRevealPwd] = useState(false);
  const [otpPopUP, setOtpPopUp] = useState(false);
  const [emailPopUP, setEmailPopUp] = useState(false);
  const [displayPopup, setDisplayPopup] = useState(true);
  const [loading, setLoading] = useState(false);
  const [isValid, setIsValid] = useState(true);
  const [inputErrors, setInputErrors] = useState({
    fName: false,
    lName: false,
    email: false,
  });
  const [Errors, setErrors] = useState({ fName: "", lName: "", email: "", passwordError:'' });
  const [captchValue, setCaptchValue] = useState("");
  const { systemLevelParameters } = useSelector(
    (state) => state.SystemLevelParameters
  );

  // Clear Token if Exists
  useEffect(() => {
    if (LocalStorageService.getAccessToken()) {
      LocalStorageService.clearToken();
    }
  }, []);

  // password validation
//   function password_validate(password) {
//     var regex = {
//       capital: /(?=.*[A-Z])/,
//       small: /(?=.*[a-z])/,
//       digit: /(?=.*[0-9])/,
//       special: /(?=.*[!@#?&%$*])/,
//       length: /(?=.{8,17})/,
//       full: /^((?!.*[\s])(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#?&%$*]).{8,17})/,
//     };

//     if (regex.length.test(password)) {
//       setPasswordValidation({ passwordValidate: false, passwordTexterror: "" });
//     } else {
//       setPasswordValidation({
//         passwordValidate: true,
//         passwordTexterror: `${t("Password length atleast 8 to 16 characters")}`,
//       });
//       return false;
//     }

    // if (regex.capital.test(password)) {
    //   setPasswordValidation({ passwordValidate: false, passwordTexterror: "" });
    // } else {
    //   setPasswordValidation({
    //     passwordValidate: true,
    //     passwordTexterror: `${t(
    //       "Password should contain at least one upper case Letter"
    //     )}`,
    //   });
    //   return false;
    // }

//     if (regex.small.test(password)) {
//       setPasswordValidation({ passwordValidate: false, passwordTexterror: "" });
//     } else {
//       setPasswordValidation({
//         passwordValidate: true,
//         passwordTexterror: `${t(
//           "Password should contain at least one lower case Letter"
//         )}`,
//       });
//       return false;
//     }

    // if (regex.digit.test(password)) {
    //   setPasswordValidation({ passwordValidate: false, passwordTexterror: "" });
    // } else {
    //   setPasswordValidation({
    //     passwordValidate: true,
    //     passwordTexterror: `${t("Password should contain at least one digit")}`,
    //   });
    //   return false;
    // }

    // if (regex.special.test(password)) {
    //   setPasswordValidation({ passwordValidate: false, passwordTexterror: "" });
    // } else {
    //   setPasswordValidation({
    //     passwordValidate: true,
    //     passwordTexterror: `${t(
    //       "Password should contain at least one special character !@#?&%$*"
    //     )}`,
    //   });
    //   return false;
    // }

    // if (regex.full.test(password)) {
    //   setPasswordValidation({ passwordValidate: false, passwordTexterror: "" });
    // } else {
    //   setPasswordValidation({
    //     passwordValidate: true,
    //     passwordTexterror: `${t('Password should not contain whitespace " "')}`,
    //   });
    //   return false;
    // }
    // return true;
//   }

  const handleGoogleCaptcha = (value) => {
    setCaptchValue(value);
  };

  // Input value change
  const onChangeHandler = (e) => {
    debugger;
    const { name, value } = e.target;
    if (name === "isTNCAccepted") {
      setInputValues({ ...inputValues, [name]: !inputValues.isTNCAccepted });
    } else {
      if (name === "fName") {
        if (value.length > 100) {
          setInputErrors({ ...inputErrors, [name]: true });
          setErrors({ ...Errors, [name]: "Max 100 characters are allowed" });
          setInputValues({ ...inputValues, [name]: value });
        } else {
          setInputValues({ ...inputValues, [name]: value });
          //setInputErrors({ ...inputErrors, [name]: false });
          setErrors({ ...Errors, [name]: "" });
        }
      }
      if(name === "lName"){
        if (value.length > 100) {
            //setInputErrors({ ...inputErrors, [name]: true });
            setErrors({ ...Errors, [name]: "Max 100 characters are allowed" });
            setInputValues({ ...inputValues, [name]: value });
          } else {
            setInputValues({ ...inputValues, [name]: value });
            //setInputErrors({ ...inputErrors, [name]: false });
            setErrors({ ...Errors, [name]: "" });
          }
      }
      if(name === "email"){
        if (value.length > 200) {
            setErrors({ ...Errors, [name]: 'Max 200 characters are allowed' });
            setInputValues({ ...inputValues, [name]: value });
        } else {
                setErrors({ ...Errors, [name]: ValidationMsg.validateEmail(value)});
                setInputValues({ ...inputValues, [name]: value });
        }
      }
      if (name === "password") {
        setErrors({ ...Errors, passwordError: ValidationMsg.validateSignUpPassword(value)});
        setInputValues({ ...inputValues, [name]: value });
        }
        if(name=== "referredCode"){
            setInputValues({ ...inputValues, [name]: value });
        }
    }
  };

  const onChangePhone = (value, country) => {
    if (country.countryCode === "dk") {
      const regex = /\d{8}/;
      if (regex.test(value.replace(country.dialCode, ""))) {
        setIsValid(false);
      } else {
        setIsValid(true);
      }
    }
    if (country.countryCode === "in") {
      const regex = /\d{10}/;
      if (regex.test(value.replace(country.dialCode, ""))) {
        setIsValid(false);
      } else {
        setIsValid(true);
      }
    }

    setInputValues({
      ...inputValues,
      countryCode: "+" + country.dialCode,
      phone: value.slice(country.dialCode.length, value.length),
    });
  };

  // SignUp Submission
  const submitHandler = (e) => {
    debugger
    e.preventDefault();
    setSubmitted(true);
    let inputObj = {
      firstName: inputValues.fName,
      lastName: inputValues.lName,
      email: inputValues.email,
      password: inputValues.password,
      phoneCountryCode: inputValues.countryCode,
      phoneNumber: inputValues.phone,
      referredCode:
        inputValues.referredCode === null ? "" : inputValues.referredCode,
      isTNCAccepted: inputValues.isTNCAccepted,
      googleCaptcha: captchValue,
    };
    let pass = ValidationMsg.validateSignUpPassword(inputObj.password);
    if (
      inputObj.firstName !== "" &&
      inputObj.lastName !== "" &&
      inputObj.email !== "" &&
      inputObj.password !== "" &&
      inputObj.phoneCountryCode !== -1 &&
      inputObj.phoneNumber !== "" &&
      inputObj.isTNCAccepted === true &&
      pass &&
      isValid === false &&
      captchValue !== ""
    ) {
        debugger
        dispatch(signUpUserInit(inputObj));
        debugger
      //setLoading(true);
    //   let URL = `${baseURL}/v1/auth/signUpInit`;
    //   axios
    //     .post(URL, inputObj)
    //     .then((response) => {
    //       debugger;
    //       if (response) {
    //         if (response?.data?.httpStatus === 200) {
                
    //           if (!LocalStorageService.getService()) {
    //             let tokenObj = {
    //               access_token: response?.data?.result?.tmpJwtToken,
    //               // refresh_token:response.data.result.tmpJwtToken,
    //             };
    //             LocalStorageService.setToken(tokenObj);
    //           }
    //           setOtpPopUp(true);
    //           setLoading(false);
    //           return true;
    //         }
    //       }
    //     })
    //     .catch((error) => {
    //       debugger;
    //       // ErrorHandlingPreLogin(error);
    //       setLoading(false);
    //       return false;
    //     });
    }
  };

  return (
    <>
      <Online>
        <div>
          {systemLevelParameters?.filter(
            (x) => x.parameterkey === "MAINTENANCE_FLAG"
          )[0]?.value === "YES" ? (
            <div className="popParent">
              <section className="prePopCent">
                <div className="finalMainte">
                  <div>
                    <img src={underMaintenanceIcon} height="300" alt="#" />
                    <h4>We will be back soon!</h4>
                  </div>
                </div>
              </section>
            </div>
          ) : (
            <React.Fragment>
              <Header />
              {!otpPopUP ? (
                <div>
                  <div className="popParent">
                    <section className="prePopCent">
                      {systemLevelParameters?.filter(
                        (x) => x.parameterkey === "FLASH_MSG"
                      )[0]?.value === "YES" ? (
                        <div className="maintenanceMode">
                          {/* <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="65" height="65" preserveAspectRatio="xMidYMid meet" viewBox="0 0 64 64"><path fill="#ffdd15" d="M63.37 53.52C53.982 36.37 44.59 19.22 35.2 2.07a3.687 3.687 0 0 0-6.522 0C19.289 19.22 9.892 36.37.508 53.52c-1.453 2.649.399 6.083 3.258 6.083h56.35c1.584 0 2.648-.853 3.203-2.01c.698-1.102.885-2.565.055-4.075"/><path fill="#1f2e35" d="m28.917 34.477l-.889-13.262c-.166-2.583-.246-4.439-.246-5.565c0-1.534.4-2.727 1.202-3.588c.805-.856 1.863-1.286 3.175-1.286c1.583 0 2.646.551 3.178 1.646c.537 1.102.809 2.684.809 4.751c0 1.215-.066 2.453-.198 3.708l-1.19 13.649c-.129 1.626-.404 2.872-.827 3.739c-.426.871-1.128 1.301-2.109 1.301c-.992 0-1.69-.419-2.072-1.257c-.393-.841-.668-2.12-.833-3.836m3.072 18.217c-1.125 0-2.106-.362-2.947-1.093c-.841-.728-1.26-1.748-1.26-3.058c0-1.143.4-2.12 1.202-2.921c.805-.806 1.786-1.206 2.951-1.206s2.153.4 2.977 1.206c.815.801 1.234 1.778 1.234 2.921c0 1.29-.419 2.308-1.246 3.044a4.245 4.245 0 0 1-2.911 1.107"/></svg> */}
                          <div className="pageDash">
                            <p>
                              {
                                systemLevelParameters?.filter(
                                  (x) => x.parameterkey === "FLASH_MSG"
                                )[0]?.description
                              }
                            </p>
                          </div>
                          {/* <div className='maintClose' onClick={()=>setHideInfoFlag(false)} >X</div> */}
                        </div>
                      ) : null}
                      <div className="">
                        <div className="heading">
                          <h5>Sign Up</h5>
                          <p>New User? Get Started Now</p>
                        </div>
                        <div className="formBody signUpForm">
                          <form
                            onSubmit={submitHandler}
                            method=""
                            autoComplete="off"
                          >
                            <ul>
                              <li className="nameGap">
                                <div className="">
                                  <label>First Name</label>
                                  <input
                                    type="text"
                                    name="fName"
                                    placeholder="First Name"
                                    onChange={onChangeHandler}
                                    value={inputValues.fName}
                                    maxLength={102}
                                    minLength={1}
                                    onKeyPress={(event) => {
                                      //debugger;
                                      let key = String.fromCharCode(
                                        !event.charCode
                                          ? event.which
                                          : event.charCode
                                      );
                                      if (ValidationMsg.validateFirstName(key) !== "") {
                                        setErrors({...Errors,fName:ValidationMsg.validateFirstName(key)});
                                        event.preventDefault();
                                        return false;
                                      } else {
                                        setErrors({
                                          ...Errors,
                                          fName:
                                            ValidationMsg.validateFirstName(
                                              key
                                            ),
                                        });
                                        return true;
                                      }
                                    }}
                                    autoComplete="off"
                                  />
                                  {Errors.fName && (
                                    <span className="error">
                                      {Errors.fName}
                                    </span>
                                  )}
                                  {submitted && !inputValues.fName && (
                                    <span className="error">
                                      Invalid First Name
                                    </span>
                                  )}
                                </div>
                                <div className="">
                                  <label>Last Name</label>
                                  <input
                                    type="text"
                                    name="lName"
                                    placeholder="Last Name"
                                    onChange={onChangeHandler}
                                    value={inputValues.lName}
                                    maxLength={102}
                                    onKeyPress={(event) => {
                                       // debugger;
                                        let key = String.fromCharCode(
                                          !event.charCode
                                            ? event.which
                                            : event.charCode
                                        );
                                        if (
                                          ValidationMsg.validateLastName(key) !==
                                          ""
                                        ) {
                                          setErrors({
                                            ...Errors,
                                            lName:
                                              ValidationMsg.validateLastName(
                                                key
                                              ),
                                          });
                                          event.preventDefault();
                                          return false;
                                        } else {
                                          setErrors({
                                            ...Errors,
                                            lName:
                                              ValidationMsg.validateLastName(
                                                key
                                              ),
                                          });
                                          return true;
                                        }
                                      }}
                                    autoComplete="off"
                                  />
                                  {Errors.lName && (
                                    <span className="error">
                                      {Errors.lName}
                                    </span>
                                  )}
                                  {submitted && !inputValues.lName && (
                                    <span className="error">
                                      Invalid Last Name
                                    </span>
                                  )}
                                </div>
                              </li>
                              <li>
                                <label>Email</label>
                                <input
                                  type="email"
                                  name="email"
                                  placeholder="Enter Email"
                                  onChange={onChangeHandler}
                                  value={inputValues.email}
                                  maxLength={202}
                                  onKeyPress={(event) => {
                                    debugger;
                                    let key = String.fromCharCode(
                                      !event.charCode
                                        ? event.which
                                        : event.charCode
                                    );
                                    if (ValidationMsg.validateEmail(key) !=="") {
                                      setErrors({...Errors,email:ValidationMsg.validateEmail(key)});
                                      return false;
                                    } else {
                                      setErrors({...Errors, email:ValidationMsg.validateEmail(key)});
                                      return true;
                                    }
                                  }}
                                  autoComplete="off"
                                />
                                {(Errors.email && (
                                  <span className="error">{Errors.email}</span>
                                )) || (submitted && !inputValues.email && (
                                    <span className="error">Invalid Email</span>
                                  ))}
                              </li>
                              <li className="phoneGap">
                                <label>Mobile</label>
                                <div className="">
                                  <PhoneInput
                                    enableSearch="false"
                                    name="phone1"
                                    country="in"
                                    onChange={onChangePhone}
                                    value={
                                      inputValues.countryCode +
                                      " " +
                                      inputValues.phone
                                    }
                                    onlyCountries={["in", "dk"]}
                                    autoFormat={true}
                                    isValid={(value, country) => {
                                      if (inputValues.phone !== "") {
                                        if (isValid) {
                                          return (
                                            "Invalid Mobile: " +
                                            value +
                                            ", for " +
                                            country.name
                                          );
                                        } else {
                                          return true;
                                        }
                                      }
                                    }}
                                    autoComplete="off"
                                  />
                                </div>
                                {submitted && !inputValues.phone && (
                                  <span className="error">
                                    Invalid Phone Number
                                  </span>
                                )}
                              </li>
                              <li className="eyeHide">
                                <label>Password</label>
                                <input
                                  type={isRevealPwd ? "text" : "password"}
                                  name="password"
                                  placeholder="Enter Password"
                                  onChange={onChangeHandler}
                                  value={inputValues.password}
                                  onPaste={(e) => {
                                    e.preventDefault();
                                    return false;
                                  }}
                                  onCopy={(e) => {
                                    e.preventDefault();
                                    return false;
                                  }}
                                  minLength={8}
                                  maxLength={16}
                                  onKeyPress={(event) => {
                                    let regex = new RegExp(/^\S/);
                                    let key = String.fromCharCode(
                                      !event.charCode
                                        ? event.which
                                        : event.charCode
                                    );
                                    if (!regex.test(key)) {
                                    //   event.preventDefault();
                                      return false;
                                    }
                                  }}
                                  autoComplete="off"
                                />
                                <div className="eyeSetup">
                                  <span className="pwd-container">
                                    <img
                                      title={
                                        isRevealPwd
                                          ? t("lbl_Hide_password")
                                          : t("lbl_show_password")
                                      }
                                      src={
                                        !isRevealPwd
                                          ? process.env
                                              .REACT_APP_IMAGE_BASE_URL +
                                            "/hide-password.svg"
                                          : process.env
                                              .REACT_APP_IMAGE_BASE_URL +
                                            "/show-password.svg"
                                      }
                                      onClick={() =>
                                        setIsRevealPwd(
                                          (prevState) => !prevState
                                        )
                                      }
                                      alt="#"
                                    />
                                  </span>
                                </div>
                                {(Errors.passwordError && (
                                  <span className="error">{Errors.passwordError}</span>
                                )) || (submitted && !inputValues.password &&<span className="error">
                                Invalid Password
                                </span>)}
                              </li>

                              <li className="eyeHide">
                                <label>Referral code</label>
                                <input
                                  type={"text"}
                                  name="referredCode"
                                  onChange={onChangeHandler}
                                  value={inputValues.referredCode}
                                  autoComplete="off"
                                />
                              </li>
                              <li className="agreeCheck">
                                <input
                                  type="checkbox"
                                  name="isTNCAccepted"
                                  onChange={onChangeHandler}
                                  checked={inputValues.isTNCAccepted}
                                />
                                <span>
                                  {t("I agree with")}{" "}
                                  <a
                                    href="https://kassio.com/tc"
                                    target="_blank"
                                    rel="noreferrer"
                                  >
                                    {t("Terms & Conditions")}
                                  </a>
                                </span>
                              </li>
                              {submitted && !inputValues.isTNCAccepted && (
                                <span className="error">
                                  {t("T/C is Required")}
                                </span>
                              )}
                              <li>
                                <Recaptcha
                                  sitekey={
                                    process.env
                                      .REACT_APP_GOOGLE_CAPCHA_PUBLIC_SITE_KEY
                                  }
                                  onChange={handleGoogleCaptcha}
                                />
                                {submitted && !captchValue && (
                                  <span className="error">
                                    Google Captcha is required
                                  </span>
                                )}
                              </li>
                              <li className="stepsWbtn">
                                <div className="levels">
                                  <span className="level1">1</span>
                                  <span className="level2">2</span>
                                  <span className="level3">3</span>
                                </div>
                                <button
                                  className="btn btnWithLoader"
                                  type="submit"
                                  onSubmit={submitHandler}
                                >
                                  {loading && (
                                    <img
                                      src={
                                        process.env.REACT_APP_IMAGE_BASE_URL +
                                        "/loader.svg"
                                      }
                                      alt="#"
                                    />
                                  )}
                                  {loading && <span>{t("Loading")}</span>}
                                  {!loading && <span>{t("NEXT")}</span>}
                                </button>
                              </li>
                              <li className="clear goToSignUp mt30 mb0">
                                <p>
                                  {t("Already have an account")}?{" "}
                                  <Link to="/">Sign In</Link>
                                </p>
                              </li>
                            </ul>
                          </form>
                        </div>
                      </div>
                    </section>
                  </div>
                  <div className="preLoginCopy">
                    Copyright 2022 © Kassio. All rights reserved.
                  </div>
                </div>
              ) : otpPopUP && !emailPopUP ? (
                <MobileOTPVerification
                  CountryCode={inputValues.countryCode}
                  MobileNo={inputValues.phone}
                  setDisplayPopup={setDisplayPopup}
                  isEmailVerify={setEmailPopUp}
                />
              ) : (
                <div>
                  {displayPopup ? (
                    <EmailOTPVerification
                      Email={inputValues.email}
                      setDisplayPopup={setDisplayPopup}
                    />
                  ) : (
                    <GoToDashboard />
                  )}
                </div>
              )}
            </React.Fragment>
          )}
        </div>
      </Online>
      <Offline>
        <NetworkConnectivity />
      </Offline>
    </>
  );
};
export default SignUp;
