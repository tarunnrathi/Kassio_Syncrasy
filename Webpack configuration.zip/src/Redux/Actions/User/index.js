import APIClient from "../../../Services/APIClient";
import { LOGIN_USER_SUCCESS,LOGIN_USER_REQUEST,LOGIN_USER_FAIL,SIGNUP_USER_INIT_REQUEST,SIGNUP_USER_INIT_SUCCESS } from "../../Constant";
import LocalStorageService from "../../../AuthServices/Storage/LocalStorageService";


/*  Action Creator for Login User */
export const loginUser =(params, navigate)=>{
    //debugger 
    return (dispatch)=>{
        APIClient.post(process.env.REACT_APP_APIS_BASE_URL+"/v1/auth/login",params)
        .then(reponse=>{
            //debugger
            dispatch({type:LOGIN_USER_REQUEST}) ;
            if(reponse.httpStatus===200){
                if (!LocalStorageService.getService()) {
                    let tokenObj = {
                        access_token: reponse?.data?.result?.jwtToken,
                        refresh_token: reponse?.data?.result?.jwtToken,
                    };
                    LocalStorageService.setToken(tokenObj);
                }
                navigate("/dashboard")
                dispatch({type:LOGIN_USER_SUCCESS, payload:true}) ;
            }
        }).catch(error=>{
            //debugger
            dispatch({
                type:LOGIN_USER_FAIL, 
                payload : error.response && error.response.data.message
                        ? error.response.data.message
                        : error.message
            });
        })
    }
};


/*  Action Creator for SignUp User */
export const signUpUserInit =(params)=>{
    debugger 
    return (dispatch)=>{
        dispatch({type : SIGNUP_USER_INIT_REQUEST})
        APIClient.post(process.env.REACT_APP_APIS_BASE_URL+"/v1/auth/signUpInit",params)
        .then(response=>{
            debugger
            if (response) {
                if (response?.data?.httpStatus === 200) {
                    if (!LocalStorageService.getService()) {
                        let tokenObj = {
                            access_token: response?.data?.result?.tmpJwtToken,
                        };
                        LocalStorageService.setToken(tokenObj);
                        dispatch({type:SIGNUP_USER_INIT_SUCCESS, payload:response?.data?.result?.tmpJwtToken})
                    }
                }
            }
        }).catch(error=>{
            debugger
            dispatch({
                type:SIGNUP_USER_INIT_FAIL, 
                payload: error.response && error.response.data.message
                        ? error.response.data.message
                        : error.message
                })
        })
    }
};