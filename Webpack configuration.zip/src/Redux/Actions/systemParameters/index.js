import APIClient from "../../../Services/APIClient";
import { GET_SYSTEM_PARAMS } from "../../Constant";


/*  Action Creator for System parameters */
export const getSystemLevelParameters = ()=>{
    return (dispatch)=>{
        APIClient.getWithoutParams(process.env.REACT_APP_APIS_BASE_URL+"/v1/misc/getAllParameterMaster")
        .then(reponse=>{
            // debugger
            if(reponse.httpStatus===200){
                dispatch({type:GET_SYSTEM_PARAMS, payload:reponse?.result});
            }
        }).catch(error=>{
            // debugger
            dispatch({type:GET_SYSTEM_PARAMS, 
                payload: error.response && error.response.data.message
                        ? error.response.data.message
                        : error.message
                    })
        })
    }
}