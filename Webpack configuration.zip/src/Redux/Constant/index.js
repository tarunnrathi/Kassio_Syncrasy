/*   System Parameters */
export const GET_SYSTEM_PARAMS = "GET_SYSTEM_PARAMS";

/*   User Login  */
export const LOGIN_USER_REQUEST = "LOGIN_USER_REQUEST";
export const LOGIN_USER_SUCCESS = "LOGIN_USER_SUCCESS";
export const LOGIN_USER_FAIL = "LOGIN_USER_FAIL";


/*   Sign Up  */
export const SIGNUP_USER_INIT_REQUEST = "SIGNUP_USER_INIT_REQUEST";
 export const SIGNUP_USER_INIT_SUCCESS = "SIGNUP_USER_INIT_SUCCESS";
 export const SIGNUP_USER_INIT_FAIL = "SIGNUP_USER_INIT_FAIL";



/*   Logout */
export const LOGOUT_USER = "LOGOUT_USER";
