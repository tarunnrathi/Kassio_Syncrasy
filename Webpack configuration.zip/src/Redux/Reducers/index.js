import {combineReducers} from 'redux';
import login,{signUpReducer} from './loginReducer';
import SystemLevelParameters from './systemParamsReducer';


const appReducer = combineReducers({
    login,
    SystemLevelParameters,
    signUp:signUpReducer

});
export default appReducer;