import { GET_SYSTEM_PARAMS } from "../Constant";

const initialState={
    systemLevelParameters:[]
};

/*  Reducer for System parameters */
export default function SystemLevelParametersReducer(state=initialState,action){
    //debugger
    switch(action.type){
         case GET_SYSTEM_PARAMS:
            return{
                ...state,
                systemLevelParameters:action.payload 
            }
         default :
            return state;  
    }
};