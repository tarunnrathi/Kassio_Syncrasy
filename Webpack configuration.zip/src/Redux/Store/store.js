import { createStore,applyMiddleware,compose } from "redux";
import appReducers from "../Reducers/index";
import thunk from 'redux-thunk';
import { persistStore, persistReducer  } from "redux-persist";
import storage from 'redux-persist/lib/storage';

const persistConfig = {
    key: "store",
    storage: storage,  
    
};

const pReducer = persistReducer(persistConfig, appReducers);
const store = createStore(pReducer,compose(
    applyMiddleware(thunk),
   // window.devToolsExtension ? window.devToolsExtension() : f => f
));
export  const persistor = persistStore(store);
export default store;