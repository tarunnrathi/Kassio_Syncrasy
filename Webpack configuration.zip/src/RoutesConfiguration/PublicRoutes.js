import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
const PublicRoutes = ({ Component, ...rest }) => {
    debugger
    const { isAuthenticated, path } = rest;
    return (
        !isAuthenticated 
        ?<Outlet />
        :<Navigate to="/" />   
    )
}
export default PublicRoutes;