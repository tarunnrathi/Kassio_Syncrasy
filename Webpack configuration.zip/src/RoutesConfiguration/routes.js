import React from 'react';

export const publicRoutes = [
    {
        path: '/',
        Component: React.lazy(() => new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve(import(/*webpackChunkName:'SignIn-Chunk' */'../Component/Login/SignIn'))
            }, 100);
        })),
        exact: true
    },
    {
        path: '/signup',
        Component: React.lazy(() => new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve(import(/*webpackChunkName:'SignUp-Chunk' */'../Component/SignUp/SignUp'))
            }, 100);
        })),
        exact: true
    }
]