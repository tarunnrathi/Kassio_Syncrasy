import axios from "axios";

class APIClient {
    // define methods
    static post(url,params,token = null){
        if(token){
            //console.log("aa");
        }
        return new Promise((resolve,reject)=>{
            axios.post(url,params)
            .then((response)=>{
                //debugger
                resolve(response.data);
            }).catch((error)=>{
                //debugger
                if(error && error.response){
                    resolve(error.response.data);
                }else{
                    reject(error);
                }
            })
        });
    };

    static getWithoutParams(url, params = null, token = null) {
        //debugger
        return new Promise(function (fulfill, reject) {
          axios
            .get(url)
            .then(function (response) {
                //debugger
              fulfill(response.data);
            })
            .catch(function (error) {
                //debugger
              if (error && error.response) {
                fulfill(error.response.data);
              } else {
                reject(error);
              }
            });
        });
      }
}
export default APIClient;