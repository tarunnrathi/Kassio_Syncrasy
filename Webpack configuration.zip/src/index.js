import React from 'react';
import ReactDOM from "react-dom/client";
import App from './App';
import reportWebVitals from './reportWebVitals';
import store from './Redux/Store/store'
import { Provider } from 'react-redux';
import LocalStorageService from './AuthServices/Storage/LocalStorageService';
import axios from 'axios';


const root = ReactDOM.createRoot(document.getElementById("root"));

// Request Timeout Handling 
axios.defaults.timeout = 30000;
axios.defaults.timeoutErrorMessage = 'Request Time Out!';


// Request interceptors
axios.interceptors.request.use(
  async config => {
    debugger
    const { origin } = new URL(config.url);
    const allowedOrigins = process.env.REACT_APP_APIS_BASE_URL;
    const token = await LocalStorageService.getAccessToken();
    if (token && allowedOrigins.includes(origin)) {
      config.headers.common['Authorization'] = token;
      config.headers.common['Content-Type'] = 'application/x-www-form-urlencoded';
      if (config.data instanceof FormData) {
        Object.assign(config.headers, config.data.getHeaders());
      }
      return config;
    }
    else {
      config.headers.common['Authorization'] = '';
      return config;
    }
    //throw ({message:"The token is not available"}); 
  }, (error => {
    Promise.reject(error);
  }), null, { synchronous: true });


// Response interceptors
axios.interceptors.response.use((response) => {
  return response;
},
  (error) => {
    if (error.code === "ECONNABORTED") {
      Swal.fire({
        icon: 'error',
        text: error?.message
      });
    }
    return Promise.reject(error);
  });


root.render(
  <Provider key={store} store={store}>
    <React.StrictMode>
      <App />
    </React.StrictMode>
  </Provider>
);
if (module.hot && process.env.NODE_ENV === "development") {
  module.hot.accept("./App", () => {
    const NextApp = require("./App").default;
    root.render(
      <Provider key={store} store={store}>
        <React.StrictMode>
          <NextApp />
        </React.StrictMode>
      </Provider>
    );
  });
}
reportWebVitals();