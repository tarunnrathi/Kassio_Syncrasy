import './App.css';
import SideBar from './SideBar';
import Tick from './ReRendering';
import MyClassComponent from './MyClassComponent';
import MemoComponent from './MemoComponent';
import Memo from './Memo';
import Test from './PureComponent';
import UseMemo from './UseMemo';
import {HOCRed,HOCGreen} from './HOC/HOC';
// import Counter from './HOC/Counter';
import NFT from './NFT/NFTs';
import NewFNTs from './NFTs/NewFNTs';
import React, { useState } from 'react';
import UseReducer from './UseReducer';
import MainComponent from './React-Redux-Data-fetching/MainComponent';
import Counter from './Custom Hooks/Counter';
import MyComponent from './Example/MyComponent';
import Game from './Amplitude/Index';
import FibonaciiSeries from './FibonaciiSeries';
import LineChart from './Chart/LineChart';
import ComponentDidUpdate from './ComponentDidUpdate';
import UserProvider from './ContextAPI/UserProvider';
import UserConsumer from './ContextAPI/UserConsumer';
import UseRef from './UseRef';
import ErrorBoundary,{OurFallbackComponent} from './ErrorBoundary';
import TensorIo from './List/TensorIo';

function App() {
  const [state,setState] = useState("Tarun");
  const changeStatevalue=(value)=>{
    setState(value);
  }
  return (
    <div>
      {/* <NewFNTs /> */}
      {/* <NFT /> */}
      {/* <HOCRed cmp={Counter} />
      <HOCGreen cmp={Counter} /> */}
      {/* <UseMemo />
      <Test /> */}
      {/* <Memo /> */}
      {/* <MemoComponent /> */}
      {/* <MyClassComponent name="Tarun" />
      <Tick /> */}      
      {/* <SideBar /> */}
      {/* <UseReducer /> */}
      {/* <MainComponent /> */}
      {/* <Counter /> */}
      {/* <MyComponent>
        <p>Hello</p>
        <p>Goodby</p>
      </MyComponent> */}
      {/* <Game /> */}
      {/* <FibonaciiSeries /> */}
      {/* <LineChart /> */}
      {/* <ComponentDidUpdate hi={state} changeStatevalue={changeStatevalue} /> */}
      {/* <UserProvider>
      <UserConsumer />
      </UserProvider> */}
      {/* <ErrorBoundary ErrorFallbackUI={Counter}>
         <UseRef />
      </ErrorBoundary> */}
      <TensorIo />
     
      

    </div>
  )
}
// const Header =({children})=>{
//   debugger
//   return(
//     <h1>{children.length}</h1>
//   )
// }
 
export default App;