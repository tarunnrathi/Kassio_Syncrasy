import React, { Component } from 'react'

class ComponentDidUpdate extends Component{
    constructor(props){
        super(props);
        this.state={
            marks:0
        }
    }
    shouldComponentUpdate=(currentProps,currentState)=>{
        debugger
        let a = this.state.marks; 
        let b = this.props.hi;
        return true;
    }

    componentDidUpdate=(preProps,preState)=>{
        debugger
        let a = this.state.marks;  
        let b = this.props.hi;
        this.setState({marks:a});
        return false;     

    }

    render(){
        debugger
        console.log("render");
        return(
            <>        
            Name : <h1>{this.props.hi}</h1>            
            Marks : <h1>{this.state.marks}</h1>  
            <button onClick={()=>{
                this.setState({marks:this.state.marks+1});
                this.props.changeStatevalue("Rathi");
            }}>Click</button>
            </>
        )
    }
}

export default ComponentDidUpdate