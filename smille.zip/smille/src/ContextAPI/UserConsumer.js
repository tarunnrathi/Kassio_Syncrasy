import React from 'react';
import userContext from "./UserContext";

const UserConsumer = (props) => {
  return (
   <userContext.Consumer>
    {(context=>{
        return(
            <React.Fragment>
                <h1>{context.name}</h1>
                <h1>{context.age}</h1>
                <div>
                <button onClick={()=>{
                    debugger
                    context.happyBirhtday()
                }}>Click</button>
                </div>
            </React.Fragment>
        )
    })}
   </userContext.Consumer>
  )
}

export default UserConsumer;