import React,{useState} from "react";
import userContext from "./UserContext";

const UserProvider = ({children}) => {
    debugger
  const [name, setName] = useState("John Doe");
  const [age, setAge] = useState(1);
  const happyBirhtday = ()=>setAge(age+1);
  return (
    <userContext.Provider value={{name,age,happyBirhtday}}>
     {children}
    </userContext.Provider>
  )
};

export default UserProvider;
