import React, { useState, useEffect } from 'react';
const Counter = () => {
    const { count, addCount, removeCount, stopCount } = useCounter(100);
    const [flag, setFlag] = useState(false);

    useEffect(() => {
        debugger
        if (flag) {
            setInterval(() => {
                addCount();
            }, 1000);
        } else {
            stopCount();
        }
    }, [count, addCount, stopCount, flag]);

    return (
        <div>
            <div className='counter'>
                {count}
            </div>
            <div>
                <button onClick={() => {
                    setFlag(true);
                }}>Add Counter</button>
                <button onClick={removeCount}>Remove Counter</button>
                <button onClick={() => {
                    setFlag(false);
                }}>Stop Counter</button>
            </div>
        </div>
    )
}
const useCounter = (initialState = 0) => {
    const [count, setCount] = useState(initialState);
    const addCount = () => setCount(count + 1);
    const removeCount = () => setCount(count - 1);
    const stopCount = () => setCount(count);
    return { count, addCount, removeCount, stopCount };
}
export default Counter;