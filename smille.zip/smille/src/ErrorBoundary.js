import React, { Component } from "react";

class ErrorBoundary extends Component {
  constructor(props) {
    debugger;
    super(props);
    this.state = {
      hasError: false,
    };
  }

  static getDerivedStateFromError(error) {    
    debugger
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  componentDidCatch() {    
    this.loggError();
  }

  loggError() {}

  render() {
    debugger
    let r = this.props;
    if (this.state.hasError) {
      // You can render any custom fallback UI
    //   return <>
    //   <h1>Something went wrong.</h1>; 
    //   </>
    return <>
     {<this.props.ErrorFallbackUI />}
      </>
    }
    return this.props.children;
  }
}
export default ErrorBoundary;

