import React from 'react';

// const MyComponent = ({ children }) => {
//     debugger
//     return (
//         <div>
//             {children.length}
//             {children.map((item, index) => {
//                 return (
//                     <div key={index}>
//                         {item.props.children}
//                     </div>
//                 )
//             })}
//         </div>
//     )
// }
// export default MyComponent;

// class MyComponent extends React.Component {
    
//     clickHandler(){
//         console.log("Clicked Pressed");
//     }
//     render() {
//         return (
//             <section>
//                 <button onClick={function() {
//                     debugger
//                     console.log("function called");
//                     console.log(this);
//                     console.log(this.props.children);
//                     this.clickHandler();
//                 }}>
//                     Click Me
//                 </button>
//             </section>
//         )
//     }
// }
// export default MyComponent;


class MyComponent extends React.Component {
    constructor(props){
        super(props);
        this.state =({userName:''});
        this.clickHandler = this.clickHandler.bind(this);
    }
    
    clickHandler(e){
        this.setState({userName:e.target.value});
    }
    render() {
        return (
            <section>
                <input type={"text"} name="userName" value={this.state.userName} onChange={this.clickHandler} />
                <p>{this.state.userName}</p>
            </section>
        )
    }
}
export default MyComponent;