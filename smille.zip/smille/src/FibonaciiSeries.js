import React, { useMemo,useState } from 'react'

const FibonaciiSeries = () => {
    const [number, setNumber] = useState(1);
    const [inc, setInc] = useState(0);

    //const finbo = useMemo(()=>factorial(number),[number]);  
    const finbo = factorial(number);  
    const onChange = event => {
        setNumber(Number(event.target.value));
    };
    const onClick = () => setInc(i => i + 1);
   
    
  return (
    <div>
        Fibonacii of  <input type="number" value={number} onChange={onChange} />
        is {finbo}
        <button onClick={onClick}>Re-render</button>      
    </div>
  )
}
  
  function finbonaci(num){ 
    //debugger
    console.log("Number = ",num);
    let num1 =0;
    let num2 =1;
    var sum; 
    var i = 0; 
    for (i = 0; i < num; i++){ 
      sum = num1 + num2; 
      num1 = num2; 
      num2 = sum; 
    } 
    return num2;     
  }
  
  function factorial(num){    
    console.log("Number = ",num);
   return num<=0?1:num*factorial(num-1);    
  }


export default FibonaciiSeries;