import React from 'react';

export const HOCRed = (props) => {
  return (
    <div>
      <h1 style={{ backgroundColor: 'red', width: 100 }}><props.cmp /></h1>
    </div>
  )
}
export const HOCGreen = (props) => {
  return (
    <div>
      <h1 style={{ backgroundColor: 'green', width: 100 }}><props.cmp /></h1>
    </div>
  )
}