import React from 'react';

class Header extends React.Component {
    constructor(inp){
        super(inp);
        this.state={states:["M","K","A"]};
    }

    

    render(){
        return(
            <>
            <input type="text" name='username' value={this.state.username} onChange={(e)=>this.setState({username:e.target.value})} />
            <p>{this.state.username}</p>
            </>
            

        )
    }
}
 
export default Header