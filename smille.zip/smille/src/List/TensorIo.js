import React, { useState, useEffect } from "react";
import axios from "axios";
import "./TensorIo.css";
import ReactPaginate from "react-paginate";
import pagesCount from "./PaginationPagesCount";
import { records_per_pages } from "./PaginationPagesCount";
import filterImage from "./filter-img.svg";
import Modal from "react-modal";

const TensorIo = () => {
  const [data, setData] = useState([]);
  const [pagination, setPagination] = useState({
    startNumber: 0,
    endNumber: records_per_pages,
  });
  const [filter, setFiter] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [record, setRecord] = useState(null);

  useEffect(() => {
    axios
      .get("https://api.spacexdata.com/v3/launches")
      .then((response) => {
        if (response?.data?.length > 0) {
          setData(response?.data);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const onPaginationChange = (e) => {
    let innerText = e.selected + 1;
    innerText = parseFloat(innerText).toString();
    if (innerText) {
      let key = Object.keys(pagesCount).filter((key) => key === innerText);
      setPagination({
        startNumber: pagesCount[key[0]],
        endNumber: pagesCount[key[0]] + records_per_pages,
      });
    }
  };

  const filterChange = (e) => {
    const { value } = e.target;
    setFiter(value);
  };

  const calculatedDate = (date) => {
    let d = new Date(date);
    const day = d.toLocaleString("default", { day: "2-digit" });
    const month = d.toLocaleString("default", { month: "long" });
    const year = d.toLocaleString("default", { year: "numeric" });
    const hour = d.toLocaleString("default", { hour: "2-digit" });
    const minute = d.toLocaleString("default", { minute: "2-digit" });
    let dateString =
      day + " " + month + " " + year + " at " + hour + ":" + minute;
    return dateString;
  };
  const modalDisplay = (item) => {    
    setShowModal(true);
    setRecord(item);
  };

  return (
    <>
      <div className="modalBackground">
        <div className="modalContainer">
          <div className="title">
            <img src={filterImage} alt="filter" width={20} height={15} />
            <select name={"filter"} onChange={filterChange}>
              <option value={""}>All Launches</option>
              <option value={"Upcoming"}>Upcoming Launches</option>
              <option value={"Success"}>Successful Launches</option>
              <option value={"Failed"}>Failed Launches</option>
            </select>
          </div>
          <div className="body">
            <div className="table-wrapper-scroll-y my-custom-scrollbar">
              <table
                className="table table-striped table-bordered table-sm"
                cellSpacing="0"
                width="100%"
              >
                <thead>
                  <tr style={{ backgroundColor: "#efeded" }}>
                    <th>No:</th>
                    <th>Launched(UTC)</th>
                    <th>Location</th>
                    <th>Mission</th>
                    <th>Orbit</th>
                    <th>Launch Status</th>
                    <th>Rocket</th>
                  </tr>
                </thead>
                <tbody>
                  {data.length > 0
                    ? data
                        ?.filter((x) => {
                          if (filter === "Upcoming") {
                            return x.upcoming;
                          } else {
                            if (filter === "Success") {
                              return x.launch_success;
                            } else {
                              if (filter === "Failed") {
                                return !x.launch_success && !x.upcoming;
                              } else {
                                return true;
                              }
                            }
                          }
                        })
                        ?.slice(pagination.startNumber, pagination.endNumber)
                        ?.map((item, index) => {
                          return (
                            <tr
                              key={item?.flight_number + index}
                              onClick={() => modalDisplay(item)}
                            >
                              <td>{item?.flight_number}</td>
                              <td>{calculatedDate(item?.launch_date_utc)}</td>
                              <td>{item?.launch_site?.site_name}</td>
                              <td>{item?.mission_name}</td>
                              <td>
                                {item?.rocket?.second_stage?.payloads?.length >
                                0
                                  ? item?.rocket?.second_stage?.payloads[0]
                                      ?.orbit
                                  : null}
                              </td>
                              <td>
                                {item?.upcoming === true
                                  ? "Upcoming"
                                  : item?.launch_success
                                  ? "Success"
                                  : "Failed"}
                              </td>
                              <td>{item?.rocket?.rocket_name}</td>
                            </tr>
                          );
                        })
                    : null}
                </tbody>
              </table>
            </div>
          </div>
          <div className="footer">
            <div className="paginate">
              <div className="paginationNav">
                <ReactPaginate
                  breakLabel="..."
                  nextLabel=">"
                  onPageChange={(e) => onPaginationChange(e)}
                  pageRangeDisplayed={records_per_pages / 5}
                  pageCount={
                    filter === ""
                      ? data.length / records_per_pages
                      : data?.filter((x) => {
                          if (filter === "Upcoming") {
                            return x.upcoming;
                          } else {
                            if (filter === "Success") {
                              return x.launch_success;
                            } else {
                              if (filter === "Failed") {
                                return !x.launch_success && !x.upcoming;
                              } else {
                                return true;
                              }
                            }
                          }
                        }).length / records_per_pages
                  }
                  previousLabel="<"
                  renderOnZeroPageCount={null}
                  containerClassName={"paginationBttns"}
                  previousLinkClassName={"previousBttn"}
                  nextLinkClassName={"nextBttn"}
                  disabledClassName={"paginationDisabled"}
                  activeClassName={"paginationActive"}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div>
        <Modal
          isOpen={showModal}
          contentLabel="onRequestClose Example"
          onRequestClose={!showModal}
          shouldCloseOnOverlayClick={false}
          className="modal-dialog"
        >
          <div className="modal-containor">
            <div className="modal-header">
              <img
                src={record?.links?.mission_patch_small}
                alt={record?.mission_name}
                height={100}
                width={100}
              />
              <span>
                <ul>
                  <li>{record?.mission_name}</li>
                  <li>{record?.rocket?.rocket_name}</li>
                </ul>
              </span>

              <span className="status">
                {record?.upcoming === true
                  ? "Upcoming"
                  : record?.launch_success
                  ? "Success"
                  : "Failed"}
              </span>
              <div className="description">
                {record?.details}
                <a href={record?.links?.wikipedia}>Wikipedia</a>
              </div>
            </div>
            <div className="modal-body">
              <ul>
                <li>
                  Flight Number
                  <span>{record?.flight_number}</span>
                  <hr />
                </li>
                <li>
                  Mission Name
                  <span>{record?.mission_name}</span>
                  <hr />
                </li>
                <li>
                  Rocket Type
                  <span>{record?.rocket?.rocket_type}</span>
                  <hr />
                </li>
                <li>
                  Rocket Name
                  <span>{record?.rocket?.rocket_name}</span>
                  <hr />
                </li>
                <li>
                  Manufacturer
                  <span>
                    {record?.rocket?.second_stage?.payloads[0]?.manufacturer}
                  </span>
                  <hr />
                </li>
                <li>
                  Nationality
                  <span>
                    {record?.rocket?.second_stage?.payloads[0]?.nationality}
                  </span>
                  <hr />
                </li>
                <li>
                  Launch Date
                  <span>{calculatedDate(record?.launch_date_utc)}</span>
                  <hr />
                </li>
                <li>
                  Payload Type
                  <span>
                    {record?.rocket?.second_stage?.payloads[0]?.payload_type}
                  </span>
                  <hr />
                </li>
                <li>
                  Orbit
                  <span>
                    {record?.rocket?.second_stage?.payloads[0]?.orbit}
                  </span>
                  <hr />
                </li>
                <li>
                  Launch Site
                  <span>{record?.launch_site?.site_name}</span>
                  <hr />
                </li>
              </ul>
            </div>
            <div className="modal-footer">
              <button onClick={() => setShowModal(false)}>Close</button>
            </div>
          </div>
        </Modal>
      </div>
    </>
  );
};

export default TensorIo;
