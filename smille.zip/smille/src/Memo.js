import React,{useState} from 'react'

const Memo = () => {
   console.log('renderApp');  
    const [count, setCount] = useState(0);
    const [items, setItems] = useState(new Array(10));

  return (
     <div>
      <h1>{count}</h1>
      <button onClick={() => setCount(count + 1)}>
        inc
      </button>  
      <List items={items} /> 
    </div>
  )
}
export default Memo;

const List=React.memo(({items})=>{
    console.log('render Lis');
    return items.map((item, key) => (
        <div key={key}>item: {item.text}</div>
      ));
});