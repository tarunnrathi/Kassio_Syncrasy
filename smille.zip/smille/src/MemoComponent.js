import React from 'react'

const MemoComponent = () => {
    const getCity=()=>{
        return 'City is Ghaziabad'
    }
    const res1 = React.useMemo(getCity,[]);
    const res2 = React.useCallback(getCity,[]);
    const res3 = React.memo(getCity,[]);
    
    console.log("City Name =",res1);
    console.log("UseCallback =",res2);
    console.log("City Name =",res3);
  return (
    <div>MemoComponent</div>
  )
}

export default MemoComponent;