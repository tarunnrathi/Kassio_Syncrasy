import React from 'react'

class MyClassComponent extends React.Component{
    constructor(props){
        super(props);
        console.log(this.props.name);
    }

    clickHandler(){
        console.log("Hi")
    }
    render(){
        return(
            <div>
                {this.props.name}
                {/* <button onClick={function(){
                    console.log("By");
                    this.clickHandler();
                }} >Click Me</button> */}
                 <button onClick={this.clickHandler()} >Click Me</button>
            </div>
        )
    }
}

export default MyClassComponent