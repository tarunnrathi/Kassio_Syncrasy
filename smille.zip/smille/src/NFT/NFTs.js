import React, { useState, useEffect } from 'react';
import axios from 'axios';


const NFT = () => {
    const [nftDetails, setNftDetails] = useState("");
    const [rankDetails, setRankDetails] = useState("");
    useEffect(() => {
        Promise.all([
            axios.get('https://s3objectlambda-test.s3.us-east-1.amazonaws.com/warm/0xed5af388653567af2f388e6224dc7c4b3241c544'),
            axios.get('https://s3objectlambda-test.s3.us-east-1.amazonaws.com/tally_ranks/0xed5af388653567af2f388e6224dc7c4b3241c544')
        ]).then(responses => {
            debugger
            setNftDetails(responses[0]?.data);
            setRankDetails(responses[1]?.data.ranks);
        }).catch(error => {

        });
    }, []);
    return (
        nftDetails && rankDetails && (
            nftDetails?.token_ids.map((item, index) => {
                debugger
                let x = nftDetails;
                let y = rankDetails;
                return (
                    <div className="naija-flag">
                        <div className="first-green"></div>
                        <div className="white">
                            <div className='img-rank'>
                                <div className='img'>
                                    <img src={`https://img.nftnerds.ai/${nftDetails?.contract_address}_${item}_96x96`} alt='#' />
                                </div>
                                <div className='rank'>
                                    <h3>#{item}</h3>
                                </div>
                            </div>
                            <div className='img-rank'>
                                <h3 style={{color:'#747471'}}>Rank:</h3>
                                <h3 style={
                                    nftDetails?.natures[index] === 1
                                        ? { color: 'green' }
                                        : nftDetails?.natures[index] === 2
                                            ? { color: 'yellow' }
                                            : nftDetails?.natures[index] === 3
                                                ? { color: 'red' }
                                                : nftDetails?.natures[index] === 4
                                                    ? { color: 'grey' }
                                                    : null
                                }>{(rankDetails[index])[0]}</h3>
                            </div>
                        </div>

                        <div className="second-green" style={
                            nftDetails?.natures[index] === 1
                                ? { backgroundColor: 'green' }
                                : nftDetails?.natures[index] === 2
                                    ? { backgroundColor: 'yellow' }
                                    : nftDetails?.natures[index] === 3
                                        ? { backgroundColor: 'red' }
                                        : nftDetails?.natures[index] === 4
                                            ? { backgroundColor: 'grey' }
                                            : null
                        } >
                        </div>
                    </div>
                )
            })
        )
    )
}

export default NFT