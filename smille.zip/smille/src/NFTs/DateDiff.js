let arr =[];

function timeDifference(start, end) {
  //  debugger
    var msPerSec = 1000 ;
    var msPerMinute = 60 * 1000;
    var msPerHour = msPerMinute * 60;
    var msPerDay = msPerHour * 24;
    var msPerMonth = msPerDay * 30;
    var msPerYear = msPerDay * 365;

    const date1 = new Date(start);
    const date2 = new Date(end);

    const diffInTime = date2.getTime() - date1.getTime();    

    if ( Math.round(diffInTime / msPerSec)>1) {
        arr.push({text:'seconds ago',value:Math.round(diffInTime / msPerSec)});
    }

    if (Math.round(diffInTime / msPerMinute)>1) {
        arr.push({text:'minutes ago',value:Math.round(diffInTime / msPerMinute)});       
    }

    if (Math.round(diffInTime / msPerHour)>1 ) {
        arr.push({text:'hours ago',value:Math.round(diffInTime / msPerHour)});        
    }

    if (Math.round(diffInTime / msPerDay)>1) {
        arr.push({text:'days ago',value:Math.round(diffInTime / msPerDay)});       
    }

    if (Math.round(diffInTime / msPerMonth)>1) {
        arr.push({text:'months ago',value:Math.floor(diffInTime / msPerMonth)});      
    }

    if(Math.round(diffInTime / msPerYear)>1) {
        arr.push({text:'years ago',value:Math.round(diffInTime / msPerYear)});       
    }
    return arr;
}

export default timeDifference;

// var oldDate = new Date( 1642790591 *1000);
// console.log("oldDate = ",oldDate)

// var myDate = new Date(); // Your timezone!
// console.log("myDate = ",myDate);


// console.log(timeDifference(oldDate,myDate));
// console.log("arr = ",arr.reduce((acc, val) => {
//     return acc < val ? acc : val;
// }) );