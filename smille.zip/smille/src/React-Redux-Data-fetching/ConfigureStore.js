import { applyMiddleware, compose, createStore } from "redux";
import thunkMiddleware from "redux-thunk";

import mainReducer from "./Reducers";
import { persistStore, persistReducer } from "redux-persist";
import storage from 'redux-persist/lib/storage';

const persistConfig = {
    key: "store",
    storage: storage,
};


const middlewares = [thunkMiddleware];
const middlewareEnhancer = applyMiddleware(...middlewares);
const enhancers = [middlewareEnhancer];
const composedEnhancers = compose(...enhancers);
const pReducer = persistReducer(persistConfig, mainReducer);
const store = createStore(pReducer,composedEnhancers);
export const persistor = persistStore(store);
export default store;