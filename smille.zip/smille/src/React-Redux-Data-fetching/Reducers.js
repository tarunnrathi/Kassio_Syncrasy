import { GET_USERS, GET_USERS_SUCCESS } from "./Action";
import { combineReducers } from 'redux';
import initialState from './State'

const reducer = (state = initialState, action) => {
    //debugger
    switch (action.type) {
        case GET_USERS:
            let r = Object.assign({}, state, {
                isLoading: true
            });
            return r;
        case GET_USERS_SUCCESS:
            let rr = Object.assign({}, state, {
                isLoading: false,
                users: action.users
            });
            return rr;
        default:
            return state;
    }
};

const mainReducer = combineReducers({
    userReducer:reducer
});
export default mainReducer;