const state = {
    users: [],
    isLoading: false
  };
  
  export default state;  