import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Add from './Image/add.png';
import Minus from './Image/minus.png';
import Folder from './Image/folder.svg';
import OpenFolder from './Image/opened-folder.svg';

const SideBar = () => {
  const [sideBarMenu, setSideBarMenu] = useState(null);
  const [values, setValues] = useState("");
  const [defaultValue,setDefaultValue] = useState(false);

  useEffect(() => {
    const headers = {
      'Content-Type': 'application/json'
    }
    const body = {
      "level": 1
    }
    axios.post("https://poc.molecularconnections.com/Tree/getTerm", body, {
      headers: headers
    }).then(response => {
      setSideBarMenu(response?.data);
    }).catch(error => {
      console.log(error);
    });
  }, []);

  const hmenuClick = (e, text) => {
    debugger  
    e.stopPropagation();    
    let d = text.split('_');
    if(d.length===1){
      document.getElementById(text).hidden = text===values && defaultValue?false:true;
      document.getElementById("add_0").setAttribute('src', text===values && defaultValue ? Minus : Add); 
      document.getElementById("folder_0").setAttribute('src', values && defaultValue ? OpenFolder  : Folder);  
    }
    if(d.length===2){     
      document.getElementById(text).hidden = text===values && defaultValue?false:true;
      document.getElementById(`add_0_${d[1]}`).setAttribute('src', text===values && defaultValue ? Minus : Add); 
      document.getElementById(`folder_0_${d[1]}`).setAttribute('src', values && defaultValue ? OpenFolder  : Folder);  
    }      
      setValues(text);
      setDefaultValue(!defaultValue);   
  }

  return (
    <div>
      {sideBarMenu &&
        sideBarMenu.child
        ?
        <ol>
          <li onClick={(e) => hmenuClick(e, "0")}>
            <img id={"add_0"} src={Minus} alt="#" />
            <img id={"folder_0"} src={OpenFolder} alt="#" />
            {sideBarMenu?.name}
            {
              sideBarMenu?.child
                ? <ol id={"0"} className="tree">
                  {sideBarMenu?.children.map((hmenu, i) => {                   
                    return (
                      <li key={i + " "} onClick={(e) => hmenuClick(e, `0_${i}`)} >
                        <img id={`add_0_${i}`}  src={Minus} alt="#" />
                        <img id={`folder_0_${i}`} src={OpenFolder} alt="#" />
                        {hmenu.name}
                        {hmenu.child 
                          ? <ol  className="tree" id={`0_${i}`} >
                            {sideBarMenu?.termsrelation?.filter(y => y.rel === hmenu.name).map((smenu) => {                              
                              return (
                                smenu?.terms.map((ssmenu, k) => {                                 
                                  return (
                                     <li key={i + " " + k}  >
                                      <img  src={Add} alt="#" />
                                      <img  src={Folder} alt="#" />
                                      {ssmenu.name}
                                    </li>
                                  )
                                })
                              )
                            })
                            }
                          </ol>
                          : null
                        }
                      </li>
                    )
                  })
                  }
                </ol>
                : null
            }

          </li>
        </ol>
        : <ol>
          {sideBarMenu?.name}
        </ol>
      }

    </div>
  )
}
export default SideBar;