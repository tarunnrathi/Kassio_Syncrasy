import React,{useState}from 'react'

const UseMemo = () => {
    const[count,setCount]=useState(0);
    const[item,setItem] = useState(new Array(3));


  return (
      <>
      {count}
      <div>
      <button onClick={()=>setCount(count+1)}>
        UseMemo Example
     </button>
     </div>
     <Calc items={item} />

      </>
    
  )
}

export default UseMemo

function Calc({items}){
    //debugger
    console.log("calc calling");
    return items.map((val,i)=>{
        return(
            <h1 key={i}>{i}</h1>
        )
    })
}