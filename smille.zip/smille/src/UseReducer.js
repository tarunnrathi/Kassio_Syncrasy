import React, { useReducer } from 'react';

// initail State
const initialState = { count: 0 };

// API logic: how to update the database when the
// 'increment' API endpoint is called

const reducer = (state, action) => {
    debugger
    switch (action.type) {
        case 'increment':
            return { count: state?.count + action?.payload };
        case 'decrement':
            return { count: state?.count - action?.payload };        
        default:
            return { count: 0 };
    }    
}

const UseReducer = () => {
    debugger
    const [state, dispatch] = useReducer(reducer, initialState);
    return (
        <div>
            Count :{state.count}
            <button onClick={() => dispatch({ type: "increment", payload: 1 })}>
                +
            </button>
            <button onClick={() => dispatch({ type: "decrement", payload: 1 })}>
                -
            </button>
            <button onClick={() => dispatch({ type: "reset", payload: 0 })}>
                Reset
            </button>
        </div>
    )
}

export default UseReducer