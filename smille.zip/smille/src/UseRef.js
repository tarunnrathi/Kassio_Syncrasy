import React, { useState, useEffect, useRef } from "react";

const UseRef = (props) => {
    const [inputValue, setInputValue] = useState("");
    const count = useRef(0);
    const inputElement = useRef();
    


    useEffect(()=>{
        count.current = count.current+1; 
       //count.current =  inputValue;
       // inputElement.current.focus();

       if(count.current >2){
       throw count.length;
       }
       
    });

    const focusInput = ()=>{
        inputElement.current.focus();
       //return new Error("aaaaaaaaaaaaaaa");
    }


  return <div>
    <input type={"number"} ref={inputElement}  value={inputValue} onChange={(e) => setInputValue(e.target.value+(inputValue||0))} />
    <h1>Render Previous Count: {count.current}</h1>
    <h1>Render Current Count: {inputValue}</h1>
    <h1>Render Current Count: {props.name}</h1>

    <button onClick={focusInput}>Focus Input</button>
  </div>;
};

export default UseRef;
