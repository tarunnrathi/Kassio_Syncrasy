import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import reportWebVitals from './reportWebVitals';
import { Provider } from "react-redux";
import App from "./App";
import { PersistGate } from "redux-persist/integration/react";
import store, { persistor } from './React-Redux-Data-fetching/ConfigureStore';


ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <PersistGate key={persistor} persistor={persistor}>
        <App />
      </PersistGate>
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);
reportWebVitals();